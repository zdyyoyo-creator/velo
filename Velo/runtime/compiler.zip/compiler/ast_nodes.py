"""Velo 抽象语法树节点定义。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple


# ============================================================ 类型注解
@dataclass
class TypeName:
    """源码中的类型写法，例如 int / list[int] / Point。"""
    name: str
    args: List["TypeName"] = field(default_factory=list)
    line: int = 0
    col: int = 0

    def __repr__(self) -> str:
        if self.args:
            return f"{self.name}[{', '.join(repr(a) for a in self.args)}]"
        return self.name


# ============================================================ 表达式
@dataclass
class Node:
    line: int = 0
    col: int = 0


@dataclass
class IntLit(Node):
    value: int = 0


@dataclass
class FloatLit(Node):
    value: float = 0.0


@dataclass
class StrLit(Node):
    # parts 中元素为 ('lit', str) 或 ('expr', Expr)
    parts: List[Tuple[str, Any]] = field(default_factory=list)


@dataclass
class BoolLit(Node):
    value: bool = False


@dataclass
class NoneLit(Node):
    pass


@dataclass
class Name(Node):
    id: str = ""


@dataclass
class BinOp(Node):
    op: str = ""
    left: Optional[Node] = None
    right: Optional[Node] = None


@dataclass
class UnaryOp(Node):
    op: str = ""
    operand: Optional[Node] = None


@dataclass
class Call(Node):
    func: Node = None
    args: List[Node] = field(default_factory=list)


@dataclass
class Attr(Node):
    obj: Optional[Node] = None
    name: str = ""


@dataclass
class Index(Node):
    obj: Optional[Node] = None
    index: Optional[Node] = None


@dataclass
class SliceExpr(Node):
    obj: Optional[Node] = None
    lower: Optional[Node] = None
    upper: Optional[Node] = None


@dataclass
class ListLit(Node):
    elems: List[Node] = field(default_factory=list)


@dataclass
class CondExpr(Node):
    cond: Optional[Node] = None
    then: Optional[Node] = None
    other: Optional[Node] = None


# ============================================================ 语句
@dataclass
class Param:
    name: str
    type_ann: Optional[TypeName]
    default: Optional[Node]
    line: int = 0
    col: int = 0


@dataclass
class VarDecl(Node):
    name: str = ""
    type_ann: Optional[TypeName] = None
    value: Optional[Node] = None
    is_const: bool = False


@dataclass
class Assign(Node):
    target: Node = None
    value: Optional[Node] = None


@dataclass
class AugAssign(Node):
    target: Node = None
    op: str = ""
    value: Optional[Node] = None


@dataclass
class ExprStmt(Node):
    value: Optional[Node] = None


@dataclass
class Return(Node):
    value: Optional[Node] = None


@dataclass
class If(Node):
    cond: Optional[Node] = None
    body: List[Node] = field(default_factory=list)
    orelse: List[Node] = field(default_factory=list)


@dataclass
class While(Node):
    cond: Optional[Node] = None
    body: List[Node] = field(default_factory=list)


@dataclass
class For(Node):
    target: str = ""
    iter: Optional[Node] = None
    body: List[Node] = field(default_factory=list)


@dataclass
class Break(Node):
    pass


@dataclass
class Continue(Node):
    pass


@dataclass
class Pass(Node):
    pass


@dataclass
class Defer(Node):
    body: List[Node] = field(default_factory=list)


@dataclass
class FuncDef(Node):
    name: str = ""
    params: List[Param] = field(default_factory=list)
    ret_type: Optional[TypeName] = None
    body: List[Node] = field(default_factory=list)
    is_extern: bool = False
    line: int = 0
    col: int = 0


@dataclass
class StructField:
    name: str
    type_ann: Optional[TypeName]
    line: int = 0
    col: int = 0


@dataclass
class StructDef(Node):
    name: str = ""
    fields: List[StructField] = field(default_factory=list)


@dataclass
class EnumDef(Node):
    name: str = ""
    variants: List[str] = field(default_factory=list)


@dataclass
class Import(Node):
    module: str = ""
    names: List[str] = field(default_factory=list)


@dataclass
class Module(Node):
    body: List[Node] = field(default_factory=list)
