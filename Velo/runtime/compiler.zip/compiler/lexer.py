"""Velo 词法分析器。

把源码切分为 token 流，并处理 Python 风格的缩进（INDENT / DEDENT）。
字符串字面量支持 {expr} 插值，插值部分拆成 ('expr', 源码) 片段交给解析器递归处理。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List


class VeloSyntaxError(Exception):
    def __init__(self, msg: str, line: int, col: int, filename: str = "<velo>"):
        self.msg = msg
        self.line = line
        self.col = col
        self.filename = filename
        super().__init__(f"{filename}:{line}:{col}: {msg}")

    def pretty(self) -> str:
        return f"\033[1;31merror\033[0m {self.filename}:{self.line}:{self.col}: {self.msg}"


KEYWORDS = {
    "def", "var", "const", "if", "elif", "else", "while", "for", "in",
    "return", "break", "continue", "struct", "enum", "import", "from", "as",
    "and", "or", "not", "is", "True", "False", "None", "pass", "defer",
    "match", "case", "extern", "export", "inout", "and",
}

# 多字符运算符，按长度降序匹配
OPERATORS = [
    "//=", "**=", "<<=", ">>=",
    "**", "//", "==", "!=", "<=", ">=", "->", "+=", "-=", "*=", "/=", "%=",
    "&=", "|=", "^=", "<<", ">>", ":=", "..",
    "+", "-", "*", "/", "%", "<", ">", "=", "(", ")", "[", "]", "{", "}",
    ",", ":", ".", "@", "&", "|", "^", "~", ";",
]

PUNCT_NEWLINE = "NEWLINE"
PUNCT_INDENT = "INDENT"
PUNCT_DEDENT = "DEDENT"
PUNCT_EOF = "EOF"


@dataclass
class Token:
    kind: str
    value: Any
    line: int
    col: int

    def __repr__(self) -> str:
        return f"Token({self.kind},{self.value!r})"


class Lexer:
    def __init__(self, src: str, filename: str = "<velo>"):
        if src.startswith("\ufeff"):
            src = src[1:]
        self.src = src.replace("\r\n", "\n").replace("\r", "\n")
        self.filename = filename
        self.pos = 0
        self.line = 1
        self.col = 1
        self.indents: List[int] = [0]
        self.tokens: List[Token] = []
        self.paren_depth = 0
        self.at_line_start = True

    # ---------------------------------------------------------------- 基础
    def error(self, msg: str, line: int | None = None, col: int | None = None):
        raise VeloSyntaxError(msg, line or self.line, col or self.col, self.filename)

    def _peek(self, off: int = 0) -> str:
        i = self.pos + off
        return self.src[i] if i < len(self.src) else ""

    def _advance(self) -> str:
        ch = self.src[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return ch

    def _emit(self, kind: str, value: Any, line: int | None = None, col: int | None = None):
        self.tokens.append(Token(kind, value, line if line is not None else self.line,
                                 col if col is not None else self.col))

    # ---------------------------------------------------------------- 缩进
    def _handle_line_start(self) -> bool:
        """处理行首缩进。返回 False 表示整行被跳过（空行/注释行）。"""
        start = self.pos
        width = 0
        while self.pos < len(self.src):
            ch = self.src[self.pos]
            if ch == " ":
                width += 1
                self._advance()
            elif ch == "\t":
                width += 4 - (width % 4)
                self._advance()
            else:
                break
        # 行尾或纯注释行：跳过整行，不影响缩进栈
        if self.pos >= len(self.src) or self.src[self.pos] == "\n" or self.src[self.pos] == "#":
            while self.pos < len(self.src) and self.src[self.pos] != "\n":
                self._advance()
            if self.pos < len(self.src):
                self._advance()          # 消费换行符，避免死循环
            self.at_line_start = True
            return False
        top = self.indents[-1]
        if width > top:
            self.indents.append(width)
            self._emit(PUNCT_INDENT, width, self.line, 1)
        elif width < top:
            while len(self.indents) > 1 and width < self.indents[-1]:
                self.indents.pop()
                self._emit(PUNCT_DEDENT, width, self.line, 1)
            if width != self.indents[-1]:
                self.error("缩进不匹配：无法对齐到任何外层缩进级别", self.line, 1)
        self.at_line_start = False
        return True

    # ---------------------------------------------------------------- 字符串
    def _read_string(self) -> List[Any]:
        """读取字符串字面量，返回 parts 列表。"""
        quote = self._peek()
        qline, qcol = self.line, self.col
        if self._peek(1) == quote and self._peek(2) == quote:
            # 三引号：多行字符串，不做插值
            self._advance(); self._advance(); self._advance()
            buf = []
            while self.pos < len(self.src):
                if self._peek() == quote and self._peek(1) == quote and self._peek(2) == quote:
                    self._advance(); self._advance(); self._advance()
                    return [("lit", "".join(buf))]
                ch = self._advance()
                if ch == "\\":
                    buf.append(self._read_escape())
                else:
                    buf.append(ch)
            self.error("多行字符串未闭合", qline, qcol)

        self._advance()
        parts: List[Any] = []
        buf: List[str] = []

        def flush():
            if buf:
                parts.append(("lit", "".join(buf)))
                buf.clear()

        while True:
            if self.pos >= len(self.src):
                self.error("字符串未闭合", qline, qcol)
            ch = self._peek()
            if ch == "\n":
                self.error("字符串未闭合（换行前缺少引号）", qline, qcol)
            if ch == quote:
                self._advance()
                break
            if ch == "\\":
                self._advance()
                buf.append(self._read_escape())
                continue
            if ch == "{":
                if self._peek(1) == "{":
                    self._advance(); self._advance()
                    buf.append("{")
                    continue
                flush()
                eline, ecol = self.line, self.col
                self._advance()  # '{'
                depth = 1
                expr_src = []
                while self.pos < len(self.src):
                    c = self._peek()
                    if c == "{":
                        depth += 1
                    elif c == "}":
                        depth -= 1
                        if depth == 0:
                            self._advance()
                            break
                    elif c in "\"'":
                        # 跳过嵌套字符串
                        q2 = c
                        expr_src.append(self._advance())
                        while self.pos < len(self.src) and self._peek() != q2:
                            if self._peek() == "\\":
                                expr_src.append(self._advance())
                            expr_src.append(self._advance())
                        if self.pos < len(self.src):
                            expr_src.append(self._advance())
                        continue
                    expr_src.append(self._advance())
                else:
                    self.error("插值表达式未闭合（缺少 }）", eline, ecol)
                parts.append(("expr", "".join(expr_src), eline, ecol))
                continue
            if ch == "}":
                if self._peek(1) == "}":
                    self._advance(); self._advance()
                    buf.append("}")
                    continue
                self.error("字符串中出现未配对的 '}'，如需字面量请写 '}}'")
            buf.append(self._advance())
        flush()
        return parts

    def _read_escape(self) -> str:
        ch = self._advance()
        mapping = {
            "n": "\n", "t": "\t", "r": "\r", "0": "\0", "\\": "\\",
            '"': '"', "'": "'", "a": "\a", "b": "\b", "f": "\f", "v": "\v",
            "{": "{", "}": "}",
        }
        if ch in mapping:
            return mapping[ch]
        if ch == "x":
            h = ""
            for _ in range(2):
                if self._peek() and self._peek() in "0123456789abcdefABCDEF":
                    h += self._advance()
            if not h:
                self.error("\\x 后需要两位十六进制数")
            return chr(int(h, 16))
        if ch == "u":
            h = ""
            for _ in range(4):
                if self._peek() and self._peek() in "0123456789abcdefABCDEF":
                    h += self._advance()
            if len(h) < 4:
                self.error("\\u 后需要四位十六进制数")
            return chr(int(h, 16))
        self.error(f"未知转义字符 \\{ch}")

    # ---------------------------------------------------------------- 数字
    def _read_number(self) -> Token:
        line, col = self.line, self.col
        start = self.pos
        is_float = False
        if self._peek() == "0" and self._peek(1) in "xXbBoO":
            base_ch = self._peek(1).lower()
            self._advance(); self._advance()
            digits = ""
            while self._peek() and (self._peek().isalnum() or self._peek() == "_"):
                digits += self._advance()
            digits = digits.replace("_", "")
            base = {"x": 16, "b": 2, "o": 8}[base_ch]
            try:
                val = int(digits, base)
            except ValueError:
                self.error("无效的数字字面量", line, col)
            return Token("INT", val, line, col)

        while self._peek() and (self._peek().isdigit() or self._peek() == "_"):
            self._advance()
        if self._peek() == "." and self._peek(1).isdigit():
            is_float = True
            self._advance()
            while self._peek() and (self._peek().isdigit() or self._peek() == "_"):
                self._advance()
        if self._peek() in "eE":
            save = self.pos
            self._advance()
            if self._peek() in "+-":
                self._advance()
            if self._peek().isdigit():
                is_float = True
                while self._peek() and (self._peek().isdigit() or self._peek() == "_"):
                    self._advance()
            else:
                self.pos = save
        text = self.src[start:self.pos].replace("_", "")
        if is_float:
            return Token("FLOAT", float(text), line, col)
        return Token("INT", int(text), line, col)

    # ---------------------------------------------------------------- 主循环
    def tokenize(self) -> List[Token]:
        while self.pos < len(self.src):
            if self.at_line_start and self.paren_depth == 0:
                if not self._handle_line_start():
                    continue
            if self.pos >= len(self.src):
                break
            ch = self._peek()

            if ch in " \t":
                self._advance()
                continue
            if ch == "#":
                while self.pos < len(self.src) and self._peek() != "\n":
                    self._advance()
                continue
            if ch == "\\" and self._peek(1) == "\n":
                self._advance(); self._advance()
                continue
            if ch == "\n":
                if self.paren_depth == 0:
                    self._emit(PUNCT_NEWLINE, "\n")
                self._advance()
                self.at_line_start = True
                continue

            line, col = self.line, self.col

            if ch.isdigit():
                self.tokens.append(self._read_number())
                continue
            if ch == "." and self._peek(1).isdigit():
                self.tokens.append(self._read_number())
                continue
            if ch in "\"'":
                parts = self._read_string()
                self._emit("STR", parts, line, col)
                continue
            if ch.isalpha() or ch == "_":
                word = ""
                while self._peek() and (self._peek().isalnum() or self._peek() == "_"):
                    word += self._advance()
                if word in KEYWORDS:
                    self._emit("KW", word, line, col)
                else:
                    self._emit("IDENT", word, line, col)
                continue

            # 运算符
            for op in OPERATORS:
                if self.src.startswith(op, self.pos):
                    for _ in op:
                        self._advance()
                    if op in "([{":
                        self.paren_depth += 1
                    elif op in ")]}":
                        self.paren_depth = max(0, self.paren_depth - 1)
                    self._emit("OP", op, line, col)
                    break
            else:
                self.error(f"无法识别的字符 {ch!r}", line, col)

        # 收尾
        if self.tokens and self.tokens[-1].kind != PUNCT_NEWLINE:
            self._emit(PUNCT_NEWLINE, "\n")
        while len(self.indents) > 1:
            self.indents.pop()
            self._emit(PUNCT_DEDENT, 0)
        self._emit(PUNCT_EOF, "")
        return self.tokens


def tokenize(src: str, filename: str = "<velo>") -> List[Token]:
    return Lexer(src, filename).tokenize()
