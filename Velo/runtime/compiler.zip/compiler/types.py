"""Velo 静态类型系统。"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class Type:
    def __str__(self) -> str:  # pragma: no cover
        return "?"


@dataclass(frozen=True)
class Prim(Type):
    name: str

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class ListT(Type):
    elem: Type

    def __str__(self) -> str:
        return f"list[{self.elem}]"


@dataclass(frozen=True)
class StructT(Type):
    name: str

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class EnumT(Type):
    name: str

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class FuncT(Type):
    params: tuple
    ret: Type

    def __str__(self) -> str:
        ps = ", ".join(str(p) for p in self.params)
        return f"fn({ps}) -> {self.ret}"


INT = Prim("int")
FLOAT = Prim("float")
BOOL = Prim("bool")
STR = Prim("str")
NONE = Prim("none")
F32 = Prim("f32")
I8 = Prim("i8")
I16 = Prim("i16")
I32 = Prim("i32")
I64 = Prim("i64")
U8 = Prim("u8")
U16 = Prim("u16")
U32 = Prim("u32")
U64 = Prim("u64")
USIZE = Prim("usize")
BYTE = Prim("byte")

PRIM_BY_NAME = {
    "int": INT, "i64": I64, "float": FLOAT, "f64": FLOAT, "f32": F32,
    "bool": BOOL, "str": STR, "none": NONE, "void": NONE,
    "i8": I8, "i16": I16, "i32": I32,
    "u8": U8, "u16": U16, "u32": U32, "u64": U64, "usize": USIZE,
    "byte": BYTE,
}

INT_KINDS = {INT, I8, I16, I32, I64, U8, U16, U32, U64, USIZE, BYTE}
FLOAT_KINDS = {FLOAT, F32}


def is_int(t: Type) -> bool:
    return isinstance(t, Prim) and t in INT_KINDS


def is_float(t: Type) -> bool:
    return isinstance(t, Prim) and t in FLOAT_KINDS


def is_numeric(t: Type) -> bool:
    return is_int(t) or is_float(t)


def is_bool(t: Type) -> bool:
    return t == BOOL


def is_str(t: Type) -> bool:
    return t == STR


def is_list(t: Type) -> bool:
    return isinstance(t, ListT)


def is_none(t: Type) -> bool:
    return t == NONE


def is_rc(t: Type) -> bool:
    """是否为需要引用计数的类型。"""
    return t == STR or isinstance(t, ListT)
