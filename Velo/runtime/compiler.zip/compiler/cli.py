"""Velo 编译器命令行入口。"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional

from . import buildenv
from .checker import VeloTypeError, check
from .codegen import generate
from .lexer import VeloSyntaxError
from .parser import parse

VERSION = "1.0.0"

GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
BOLD = "\033[1m"
RESET = "\033[0m"


def color_enabled() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("VELO_NO_COLOR"):
        return False
    return sys.stdout.isatty()


def c(text: str, code: str) -> str:
    if not color_enabled():
        return text
    return f"{code}{text}{RESET}"


def info(msg: str):
    print(f"{c('[velo]', CYAN)} {msg}")


def error(msg: str):
    print(f"{c('error', RED + BOLD)}: {msg}", file=sys.stderr)


def warn(msg: str):
    print(f"{c('warning', YELLOW)}: {msg}", file=sys.stderr)


HELP = f"""
{VERSION and 'Velo'} 语言编译器 veloc {VERSION}
类 Python 语法，静态类型，编译为原生机器码（经由优化的 C 后端）。

用法:
  veloc build <文件.velo> [选项]      编译为可执行文件
  veloc run   <文件.velo> [参数...]   编译后立即运行
  veloc check <文件.velo>             只做语法与类型检查
  veloc emitc <文件.velo> [-o out.c]  输出生成的 C 代码
  veloc env                           显示使用的编译器后端信息
  veloc version                       显示版本
  veloc help                          显示本帮助

build 选项:
  -o, --output <路径>     输出 exe 路径（默认与源文件同名）
  -O <0|1|2|3>            优化等级（0=调试, 2=默认最快）
  --debug                 调试构建（关闭优化、保留符号）
  --fast                  激进优化（启用 AVX2，需要较新的 CPU）
  --emit-c <路径>         同时把生成的 C 代码保存到指定文件
  --keep                  保留中间文件（便于排查）
  --quiet                 只输出错误

示例:
  veloc run hello.velo
  veloc build fib.velo -o fib.exe --fast
  veloc emitc primes.velo -o primes.c

性能说明: Velo 生成单一编译单元的 C 代码，由 MSVC 以 /O2 优化，
数值计算会直接编译为机器指令，速度与等价的 C 代码相同。
"""


# ---------------------------------------------------------------- 编译流程
def load_and_compile(src_path: Path, emit_c: Optional[Path] = None,
                     mode: str = "release", keep: bool = False,
                     out_exe: Optional[Path] = None, quiet: bool = False) -> Path:
    t0 = time.time()
    if not src_path.exists():
        raise SystemExit(f"源文件不存在: {src_path}")
    source = src_path.read_text(encoding="utf-8")
    filename = src_path.name

    try:
        module = parse(source, filename)
    except VeloSyntaxError as e:
        error(f"{filename}:{e.line}:{e.col}: {e.msg}")
        raise SystemExit(1)

    try:
        ck = check(module, filename, source)
    except VeloTypeError as e:
        error(f"{filename}:{e.line}:{e.col}: {e.msg}")
        raise SystemExit(1)

    gen = generate(module, ck, filename, source)

    if emit_c is not None:
        emit_c.parent.mkdir(parents=True, exist_ok=True)
        emit_c.write_text(gen, encoding="utf-8")

    exe = out_exe if out_exe else src_path.with_suffix(".exe")
    if not quiet:
        info(f"类型检查通过 · 生成 C 代码 {gen.count(chr(10))} 行")

    workdir = None
    if keep:
        workdir = src_path.with_suffix("").parent / (src_path.stem + ".velo_build")

    try:
        res = buildenv.compile_c_to_exe(gen, exe, mode=mode, keep_dir=workdir)
    except buildenv.BuildError as e:
        error(str(e))
        raise SystemExit(1)

    if not res["ok"]:
        error("C 后端编译失败。下面是编译器输出：")
        out = str(res["output"])
        print(out[:6000], file=sys.stderr)
        if res.get("c_file"):
            print(f"\n生成的 C 代码已保留: {res['c_file']}", file=sys.stderr)
        else:
            print("\n提示：加 --keep 可保留生成的 C 代码以便排查。", file=sys.stderr)
        raise SystemExit(1)

    dt = time.time() - t0
    if not quiet:
        try:
            size = exe.stat().st_size
            info(f"{c('完成', GREEN)} {exe.name}  ({size / 1024:.1f} KB, 用时 {dt:.2f}s)")
        except OSError:
            info(f"{c('完成', GREEN)} {exe}")
    return exe


def find_sources(arg: str) -> Path:
    p = Path(arg)
    if p.suffix != ".velo" and p.with_suffix(".velo").exists():
        p = p.with_suffix(".velo")
    return p


# ---------------------------------------------------------------- 子命令
def cmd_build(args: List[str]) -> int:
    if not args:
        error("缺少源文件，例如：veloc build hello.velo")
        return 1
    src = find_sources(args[0])
    out: Optional[Path] = None
    emit_c: Optional[Path] = None
    mode = "release"
    keep = False
    quiet = False
    i = 1
    while i < len(args):
        a = args[i]
        if a in ("-o", "--output"):
            i += 1
            out = Path(args[i])
        elif a == "-O" or a.startswith("-O"):
            lvl = a[2:] if len(a) > 2 else (args[i + 1] if i + 1 < len(args) else "2")
            if len(a) == 2:
                i += 1
            mode = "debug" if lvl == "0" else ("fast" if lvl in ("3",) else "release")
        elif a == "--debug":
            mode = "debug"
        elif a == "--fast":
            mode = "fast"
        elif a == "--emit-c":
            i += 1
            emit_c = Path(args[i])
        elif a == "--keep":
            keep = True
        elif a == "--quiet":
            quiet = True
        else:
            error(f"未知选项 {a}")
            return 1
        i += 1
    try:
        load_and_compile(src, emit_c=emit_c, mode=mode, keep=keep, out_exe=out, quiet=quiet)
    except SystemExit as e:
        return int(e.code or 0)
    return 0


def cmd_run(args: List[str]) -> int:
    if not args:
        error("缺少源文件，例如：veloc run hello.velo")
        return 1
    src = find_sources(args[0])
    prog_args = args[1:]
    out = src.with_suffix(".exe")
    try:
        exe = load_and_compile(src, mode="release", out_exe=out, quiet=True)
    except SystemExit as e:
        return int(e.code or 0)
    try:
        p = subprocess.run([str(exe)] + prog_args)
    except KeyboardInterrupt:
        return 130
    return p.returncode


def cmd_check(args: List[str]) -> int:
    if not args:
        error("缺少源文件")
        return 1
    src = find_sources(args[0])
    try:
        source = src.read_text(encoding="utf-8")
    except OSError as e:
        error(str(e))
        return 1
    try:
        module = parse(source, src.name)
        check(module, src.name, source)
    except VeloSyntaxError as e:
        error(f"{src.name}:{e.line}:{e.col}: {e.msg}")
        return 1
    except VeloTypeError as e:
        error(f"{src.name}:{e.line}:{e.col}: {e.msg}")
        return 1
    info(f"{c('语法与类型检查通过', GREEN)} — {src.name}")
    return 0


def cmd_emitc(args: List[str]) -> int:
    if not args:
        error("缺少源文件")
        return 1
    src = find_sources(args[0])
    out = src.with_suffix(".c")
    if len(args) >= 3 and args[1] in ("-o", "--output"):
        out = Path(args[2])
    try:
        source = src.read_text(encoding="utf-8")
        module = parse(source, src.name)
        ck = check(module, src.name, source)
        code = generate(module, ck, src.name, source)
    except (VeloSyntaxError, VeloTypeError) as e:
        error(f"{src.name}:{e.line}:{e.col}: {e.msg}")
        return 1
    out.write_text(code, encoding="utf-8")
    info(f"已生成 C 代码: {out}")
    return 0


def cmd_env(args: List[str]) -> int:
    import tempfile
    print(f"Velo 编译器 {VERSION}")
    print(f"Python      {sys.version.split()[0]} ({sys.executable})")
    print(f"平台        {sys.platform}")
    print(f"工作目录    {os.getcwd()}")
    print(f"临时目录    {tempfile.gettempdir()}")
    print(f"TEMP        {os.environ.get('TEMP')}")
    print(f"环境变量数  {len(os.environ)}")
    try:
        vc = buildenv.find_vcvars()
        print(f"vcvars      {vc}")
        print(f"cl.exe      {buildenv.cl_location()}")
        env = buildenv.msvc_env()
        print(f"MSVC 环境   INCLUDE={'INCLUDE' in env}  LIB={'LIB' in env}")
    except Exception as e:
        print(f"后端错误    {e}")
        return 1
    print(f"运行时库    {buildenv.runtime_dir()}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        print(HELP)
        return 0
    cmd = args[0]
    rest = args[1:]
    if cmd in ("-h", "--help", "help"):
        print(HELP)
        return 0
    if cmd in ("-v", "--version", "version"):
        print(f"Velo 语言 1.0  ·  veloc {VERSION}")
        return 0
    if cmd == "build":
        return cmd_build(rest)
    if cmd == "run":
        return cmd_run(rest)
    if cmd == "check":
        return cmd_check(rest)
    if cmd in ("emitc", "emit-c"):
        return cmd_emitc(rest)
    if cmd == "env":
        return cmd_env(rest)
    # 允许直接 veloc file.velo 运行
    if cmd.endswith(".velo") or Path(cmd).with_suffix(".velo").exists():
        return cmd_run(args)
    error(f"未知命令 {cmd!r}，运行 `veloc help` 查看用法")
    return 1


if __name__ == "__main__":
    sys.exit(main())
