"""Velo 语义分析：符号收集 + 静态类型检查。

为每个表达式节点写入 node.ty，供代码生成阶段直接使用。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import ast_nodes as A
from .types import (
    BOOL, BYTE, F32, FLOAT, I8, I16, I32, I64, INT, NONE, PRIM_BY_NAME, STR,
    U8, U16, U32, U64, USIZE, EnumT, FuncT, ListT, Prim, StructT, Type,
    is_bool, is_float, is_int, is_list, is_none, is_numeric, is_rc, is_str,
)


class VeloTypeError(Exception):
    def __init__(self, msg: str, line: int, col: int, filename: str = "<velo>"):
        self.msg = msg
        self.line = line
        self.col = col
        self.filename = filename
        super().__init__(msg)

    def pretty(self) -> str:
        return f"\033[1;31merror\033[0m {self.filename}:{self.line}:{self.col}: {self.msg}"


@dataclass
class FuncInfo:
    name: str
    params: List[Tuple[str, Type]]
    ret: Type
    node: A.FuncDef
    is_extern: bool = False


@dataclass
class StructInfo:
    name: str
    fields: List[Tuple[str, Type]]
    node: A.StructDef


@dataclass
class EnumInfo:
    name: str
    variants: List[str]
    node: A.EnumDef


BUILTIN_FUNCS = {
    "print", "println", "eprint", "eprintln", "len", "abs", "min", "max",
    "sqrt", "pow", "sin", "cos", "tan", "asin", "acos", "atan", "atan2",
    "log", "log2", "log10", "exp", "floor", "ceil", "round", "trunc",
    "int", "to_int", "float", "to_float", "str", "to_str", "panic", "assert",
    "exit", "sort", "reverse", "utf8_len", "arg_count", "arg",
    "read_file", "write_file", "file_exists", "fill",
}

MATH1 = {"sqrt", "sin", "cos", "tan", "asin", "acos", "atan",
         "log", "log2", "log10", "exp", "floor", "ceil", "round", "trunc"}


class Checker:
    def __init__(self, module: A.Module, filename: str = "<velo>", source: str = ""):
        self.module = module
        self.filename = filename
        self.src_lines = source.splitlines()
        self.structs: Dict[str, StructInfo] = {}
        self.enums: Dict[str, EnumInfo] = {}
        self.funcs: Dict[str, FuncInfo] = {}
        self.globals: Dict[str, Type] = {}
        self.scopes: List[Dict[str, Type]] = []
        self.cur_ret: Type = NONE
        self.in_loop = 0
        self.has_user_main = False
        self.const_names: set = set()

    # ------------------------------------------------------------ 错误
    def err(self, msg: str, node) -> None:
        raise VeloTypeError(msg, getattr(node, "line", 0), getattr(node, "col", 0), self.filename)

    def note(self, node) -> str:
        ln = getattr(node, "line", 0)
        if 1 <= ln <= len(self.src_lines):
            return self.src_lines[ln - 1]
        return ""

    # ------------------------------------------------------------ 作用域
    def push(self):
        self.scopes.append({})

    def pop(self):
        self.scopes.pop()

    def declare(self, name: str, ty: Type, node):
        if not self.scopes:
            self.err("内部错误：没有活动作用域", node)
        scope = self.scopes[-1]
        if name in scope:
            self.err(f"变量 {name!r} 已经被声明", node)
        scope[name] = ty

    def lookup(self, name: str) -> Optional[Type]:
        for sc in reversed(self.scopes):
            if name in sc:
                return sc[name]
        return self.globals.get(name)

    # ------------------------------------------------------------ 类型解析
    def resolve_type(self, tn: A.TypeName) -> Type:
        base = tn.name
        if base in PRIM_BY_NAME and not tn.args:
            return PRIM_BY_NAME[base]
        if base in ("list", "vec") and len(tn.args) == 1:
            elem = self.resolve_type(tn.args[0])
            return ListT(elem)
        if base in self.structs and not tn.args:
            return StructT(base)
        if base in self.enums and not tn.args:
            return EnumT(base)
        if base in PRIM_BY_NAME:
            self.err(f"类型 {base} 不接受类型参数", tn)
        self.err(f"未知类型 {base!r}", tn)

    def same(self, a: Type, b: Type) -> bool:
        return a == b

    def assignable(self, got: Type, want: Type) -> bool:
        if got == want:
            return True
        if is_int(got) and is_int(want):
            return True
        if is_int(got) and is_float(want):
            return True
        if is_float(got) and is_float(want):
            return True
        return False

    def need(self, got: Type, want: Type, node, what: str = "值"):
        if not self.assignable(got, want):
            self.err(f"{what}类型不匹配：期望 {want}，实际是 {got}", node)

    # ------------------------------------------------------------ 收集声明
    def collect(self):
        body = self.module.body
        for st in body:
            if isinstance(st, A.StructDef):
                if st.name in self.structs:
                    self.err(f"结构体 {st.name!r} 重复定义", st)
                self.structs[st.name] = StructInfo(st.name, [], st)
            elif isinstance(st, A.EnumDef):
                if st.name in self.enums:
                    self.err(f"枚举 {st.name!r} 重复定义", st)
                self.enums[st.name] = EnumInfo(st.name, list(st.variants), st)
            elif isinstance(st, A.FuncDef):
                if st.name in self.funcs:
                    self.err(f"函数 {st.name!r} 重复定义", st)

        # 先占位函数，支持互相递归调用
        for st in body:
            if isinstance(st, A.FuncDef):
                self.funcs[st.name] = FuncInfo(st.name, [], NONE, st, st.is_extern)

        # 解析结构体字段
        for info in self.structs.values():
            fields: List[Tuple[str, Type]] = []
            seen = set()
            for f in info.node.fields:
                if f.name in seen:
                    self.err(f"字段 {f.name!r} 重复定义", f)
                seen.add(f.name)
                ty = self.resolve_type(f.type_ann)
                if is_rc(ty) or isinstance(ty, ListT):
                    self.err(
                        f"Velo 1.0 暂不支持结构体字段使用 {ty}（引用计数字段会引入隐藏开销）；"
                        f"请改用 int/float/bool 或其他结构体字段", f)
                fields.append((f.name, ty))
            info.fields = fields

        # 解析函数签名
        for name, info in self.funcs.items():
            params: List[Tuple[str, Type]] = []
            seen = set()
            for p in info.node.params:
                if p.name in seen:
                    self.err(f"参数 {p.name!r} 重复", p)
                seen.add(p.name)
                if p.default is not None:
                    self.err(f"参数 {p.name!r}：Velo 1.0 暂不支持默认参数，请显式传参", p)
                if p.type_ann is None:
                    self.err(f"参数 {p.name!r} 缺少类型注解", p)
                params.append((p.name, self.resolve_type(p.type_ann)))
            ret = self.resolve_type(info.node.ret_type) if info.node.ret_type else NONE
            info.params = params
            info.ret = ret
        self.has_user_main = "main" in self.funcs

    # ------------------------------------------------------------ 入口
    def run(self):
        self.collect()
        # 顶层变量声明 -> 全局
        for st in self.module.body:
            if isinstance(st, A.VarDecl):
                vty: Optional[Type] = None
                if st.type_ann is not None:
                    vty = self.resolve_type(st.type_ann)
                if st.value is not None:
                    gty = self.check_expr(st.value, vty)
                    if vty is None:
                        vty = gty
                    else:
                        self.need(gty, vty, st.value, "初始化")
                if vty is None:
                    self.err(f"全局变量 {st.name!r} 需要类型注解", st)
                st.ty = vty
                if st.name in self.globals:
                    self.err(f"全局变量 {st.name!r} 重复定义", st)
                self.globals[st.name] = vty

        # 检查函数体
        for name, info in self.funcs.items():
            if info.is_extern:
                continue
            self.check_func(info)

        # 检查顶层非声明语句
        self.check_toplevel()

        if not self.has_user_main:
            pass  # 允许纯脚本形式

    def check_toplevel(self):
        stmts = [st for st in self.module.body
                 if not isinstance(st, (A.FuncDef, A.StructDef, A.EnumDef, A.Import))]
        if not stmts:
            return
        self.push()
        try:
            for st in stmts:
                if isinstance(st, A.VarDecl):
                    continue  # 已在全局处理
                self.check_stmt(st)
        finally:
            self.pop()

    def check_func(self, info: FuncInfo):
        self.cur_ret = info.ret
        self.push()
        try:
            for pname, pty in info.params:
                self.declare(pname, pty, info.node)
            for st in info.node.body:
                self.check_stmt(st)
            if not is_none(info.ret) and not self.always_returns(info.node.body):
                self.err(f"函数 {info.name!r} 声明返回 {info.ret}，但存在没有 return 的路径", info.node)
        finally:
            self.pop()
            self.cur_ret = NONE

    def always_returns(self, stmts: List[A.Node]) -> bool:
        for st in stmts:
            if isinstance(st, A.Return):
                return True
            if isinstance(st, A.If):
                if st.orelse and self.always_returns(st.body) and self.always_returns(st.orelse):
                    return True
        return False

    # ------------------------------------------------------------ 语句
    def check_body(self, body: List[A.Node]):
        self.push()
        try:
            for st in body:
                self.check_stmt(st)
        finally:
            self.pop()

    def check_stmt(self, st: A.Node):
        if isinstance(st, A.VarDecl):
            declared: Optional[Type] = None
            if st.type_ann is not None:
                declared = self.resolve_type(st.type_ann)
            vty: Optional[Type] = None
            if st.value is not None:
                vty = self.check_expr(st.value, declared)
            if declared is None:
                if vty is None:
                    self.err(f"变量 {st.name!r} 无法推断类型，请添加类型注解", st)
                if isinstance(vty, ListT) and isinstance(st.value, A.ListLit) and not st.value.elems:
                    self.err(f"空列表无法推断元素类型，请写成 var {st.name}: list[int] = []", st)
                declared = vty
            else:
                if vty is not None:
                    self.need(vty, declared, st.value, "赋值")
                elif is_rc(declared):
                    self.err(f"{declared} 变量 {st.name!r} 必须给出初始值（引用计数类型不能默认初始化）", st)
            st.ty = declared
            if st.is_const:
                self.const_names.add(st.name)
            self.declare(st.name, declared, st)

        elif isinstance(st, A.Assign):
            tty = self.check_expr(st.target)
            vty = self.check_expr(st.value, tty)
            self.need(vty, tty, st.value, "赋值")
            if self.is_const_name(st.target):
                self.err("不能给 const 常量赋值", st)
            st.ty = tty

        elif isinstance(st, A.AugAssign):
            tty = self.check_expr(st.target)
            vty = self.check_expr(st.value, tty)
            op = st.op
            if op == "+" and is_str(tty) and is_str(vty):
                st.result_ty = STR
            elif is_numeric(tty) and is_numeric(vty):
                if op == "/":
                    self.err("`/=` 请改用 `*=` 或显式转换为 float", st)
                st.result_ty = tty if not is_float(vty) else (FLOAT if is_float(tty) else tty)
            else:
                self.err(f"运算符 {op}= 不支持 {tty} 与 {vty}", st)
            if self.is_const_name(st.target):
                self.err("不能修改 const 常量", st)
            st.ty = tty

        elif isinstance(st, A.ExprStmt):
            t = self.check_expr(st.value)
            if is_rc(t):
                self.err("表达式的结果（含引用计数）被直接丢弃，会造成内存泄漏；"
                         "请赋值给变量，或改用 print 输出", st)

        elif isinstance(st, A.Return):
            if st.value is None:
                if not is_none(self.cur_ret):
                    self.err(f"函数需要返回 {self.cur_ret}，但 return 没有给出值", st)
            else:
                vty = self.check_expr(st.value, self.cur_ret)
                if is_none(self.cur_ret):
                    if not is_none(vty):
                        self.err(f"函数声明不返回值，却 return 了 {vty}", st)
                else:
                    self.need(vty, self.cur_ret, st.value, "返回值")

        elif isinstance(st, A.If):
            cty = self.check_expr(st.cond)
            if not is_bool(cty):
                self.err(f"if 条件必须是 bool，实际是 {cty}", st.cond)
            self.check_body(st.body)
            if st.orelse:
                self.check_body(st.orelse)

        elif isinstance(st, A.While):
            cty = self.check_expr(st.cond)
            if not is_bool(cty):
                self.err(f"while 条件必须是 bool，实际是 {cty}", st.cond)
            self.in_loop += 1
            try:
                self.check_body(st.body)
            finally:
                self.in_loop -= 1

        elif isinstance(st, A.For):
            self.check_for(st)

        elif isinstance(st, A.Break):
            if self.in_loop == 0:
                self.err("break 只能出现在循环里", st)

        elif isinstance(st, A.Continue):
            if self.in_loop == 0:
                self.err("continue 只能出现在循环里", st)

        elif isinstance(st, A.Pass):
            pass

        elif isinstance(st, A.FuncDef):
            self.err("Velo 1.0 不支持在函数内部定义函数，请把函数移到顶层", st)

        elif isinstance(st, A.StructDef) or isinstance(st, A.EnumDef):
            self.err("结构体 / 枚举只能在顶层定义", st)

        elif isinstance(st, A.Import):
            pass

        else:
            self.err(f"不支持的语句类型 {type(st).__name__}", st)

    def is_const_name(self, target: A.Node) -> bool:
        if not isinstance(target, A.Name):
            return False
        return target.id in self.const_names

    def check_for(self, st: A.For):
        it = st.iter
        if isinstance(it, A.Call) and isinstance(it.func, A.Name) and it.func.id == "range":
            n = len(it.args)
            if n < 1 or n > 3:
                self.err("range() 接受 1~3 个参数", it)
            for a in it.args:
                t = self.check_expr(a)
                if not is_int(t):
                    self.err(f"range() 的参数必须是 int，实际是 {t}", a)
            it.ty = ListT(INT)
            st.iter_kind = "range"
            self.in_loop += 1
            self.push()
            try:
                self.declare(st.target, INT, st)
                for s in st.body:
                    self.check_stmt(s)
            finally:
                self.pop()
                self.in_loop -= 1
            return

        ity = self.check_expr(it)
        if isinstance(ity, ListT):
            st.iter_kind = "list"
            self.in_loop += 1
            self.push()
            try:
                self.declare(st.target, ity.elem, st)
                for s in st.body:
                    self.check_stmt(s)
            finally:
                self.pop()
                self.in_loop -= 1
            return
        self.err(f"for 只能遍历 list 或 range()，实际是 {ity}", it)

    # ------------------------------------------------------------ 表达式
    def setty(self, node: A.Node, ty: Type) -> Type:
        node.ty = ty
        return ty

    def check_expr(self, e: A.Node, expected: Optional[Type] = None) -> Type:
        if isinstance(e, A.IntLit):
            return self.setty(e, INT)
        if isinstance(e, A.FloatLit):
            return self.setty(e, FLOAT)
        if isinstance(e, A.BoolLit):
            return self.setty(e, BOOL)
        if isinstance(e, A.NoneLit):
            return self.setty(e, NONE)

        if isinstance(e, A.StrLit):
            for kind, val in e.parts:
                if kind != "expr":
                    continue
                t = self.check_expr(val)
                if is_none(t):
                    self.err("不能把 none 插入字符串", val)
                if is_list(t):
                    self.err("字符串插值暂不支持 list，请先逐个元素输出", val)
                if isinstance(t, (StructT, EnumT)):
                    self.err(f"字符串插值暂不支持 {t}，请插入它的字段", val)
            return self.setty(e, STR)

        if isinstance(e, A.Name):
            ty = self.lookup(e.id)
            if ty is None:
                self.err(f"未定义的名称 {e.id!r}", e)
            return self.setty(e, ty)

        if isinstance(e, A.BinOp):
            return self.check_binop(e)

        if isinstance(e, A.UnaryOp):
            t = self.check_expr(e.operand)
            if e.op == "not":
                if not is_bool(t):
                    self.err(f"not 需要 bool，实际是 {t}", e)
                return self.setty(e, BOOL)
            if e.op == "-":
                if not is_numeric(t):
                    self.err(f"一元 - 需要数值类型，实际是 {t}", e)
                return self.setty(e, t)
            if e.op == "+":
                if not is_numeric(t):
                    self.err(f"一元 + 需要数值类型，实际是 {t}", e)
                return self.setty(e, t)
            if e.op == "~":
                if not is_int(t):
                    self.err(f"位取反需要整数，实际是 {t}", e)
                return self.setty(e, INT)
            self.err(f"未知一元运算符 {e.op}", e)

        if isinstance(e, A.Call):
            return self.check_call(e)

        if isinstance(e, A.Attr):
            return self.check_attr(e)

        if isinstance(e, A.Index):
            ot = self.check_expr(e.obj)
            ity = self.check_expr(e.index)
            if not is_int(ity):
                self.err(f"索引必须是 int，实际是 {ity}", e.index)
            if isinstance(ot, ListT):
                return self.setty(e, ot.elem)
            if is_str(ot):
                return self.setty(e, STR)
            self.err(f"类型 {ot} 不支持下标访问", e)

        if isinstance(e, A.SliceExpr):
            ot = self.check_expr(e.obj)
            if e.lower is not None:
                lt = self.check_expr(e.lower)
                if not is_int(lt):
                    self.err("切片下界必须是 int", e.lower)
            if e.upper is not None:
                ut = self.check_expr(e.upper)
                if not is_int(ut):
                    self.err("切片上界必须是 int", e.upper)
            if isinstance(ot, ListT):
                self.err("Velo 1.0 暂不支持 list 切片，请用循环复制", e)
            if is_str(ot):
                return self.setty(e, STR)
            self.err(f"类型 {ot} 不支持切片", e)

        if isinstance(e, A.ListLit):
            if not e.elems:
                if expected is not None and isinstance(expected, ListT):
                    return self.setty(e, expected)
                return self.setty(e, ListT(NONE))
            elem_t: Optional[Type] = None
            for el in e.elems:
                t = self.check_expr(el, expected.elem if isinstance(expected, ListT) else None)
                if elem_t is None:
                    elem_t = t
                elif not self.assignable(t, elem_t):
                    if self.assignable(elem_t, t):
                        elem_t = t
                    else:
                        self.err(f"列表元素类型不一致：{elem_t} 与 {t}", el)
            assert elem_t is not None
            if is_rc(elem_t):
                pass
            if isinstance(elem_t, StructT):
                self.err("Velo 1.0 暂不支持结构体作为列表元素，请改用并行数组", e)
            if is_none(elem_t):
                self.err("列表元素不能是 none", e)
            return self.setty(e, ListT(elem_t))

        if isinstance(e, A.CondExpr):
            cty = self.check_expr(e.cond)
            if not is_bool(cty):
                self.err(f"条件表达式需要 bool，实际是 {cty}", e.cond)
            at = self.check_expr(e.then, expected)
            bt = self.check_expr(e.other, expected)
            if is_rc(at) or is_rc(bt):
                self.err("条件表达式暂不支持 str / list 结果，请改用 if 语句", e)
            if self.assignable(at, bt):
                return self.setty(e, bt)
            if self.assignable(bt, at):
                return self.setty(e, at)
            self.err(f"条件表达式两个分支类型不一致：{at} 与 {bt}", e)

        self.err(f"不支持的表达式类型 {type(e).__name__}", e)

    def check_binop(self, e: A.BinOp) -> Type:
        op = e.op
        lt = self.check_expr(e.left)
        rt = self.check_expr(e.right)

        if op in ("+", "-", "*"):
            if op == "+" and (is_str(lt) or is_str(rt)):
                if not (is_str(lt) and is_str(rt)):
                    self.err(f"字符串只能和字符串相加，实际是 {lt} 与 {rt}", e)
                return self.setty(e, STR)
            if is_numeric(lt) and is_numeric(rt):
                if op == "*" and (is_str(lt) or is_str(rt)):
                    pass
                return self.setty(e, FLOAT if (is_float(lt) or is_float(rt)) else INT)
            if op == "*" and (is_str(lt) and is_int(rt)) or (is_int(lt) and is_str(rt)):
                return self.setty(e, STR)
            self.err(f"运算符 {op} 不支持 {lt} 与 {rt}", e)

        if op == "/":
            if is_numeric(lt) and is_numeric(rt):
                return self.setty(e, FLOAT)
            self.err(f"除法需要数值类型，实际是 {lt} 与 {rt}", e)

        if op == "//":
            if is_int(lt) and is_int(rt):
                return self.setty(e, INT)
            if is_numeric(lt) and is_numeric(rt):
                return self.setty(e, FLOAT)
            self.err(f"整除需要数值类型，实际是 {lt} 与 {rt}", e)

        if op == "%":
            if is_int(lt) and is_int(rt):
                return self.setty(e, INT)
            if is_numeric(lt) and is_numeric(rt):
                return self.setty(e, FLOAT)
            self.err(f"取模需要数值类型，实际是 {lt} 与 {rt}", e)

        if op == "**":
            if is_int(lt) and is_int(rt):
                return self.setty(e, INT)
            if is_numeric(lt) and is_numeric(rt):
                return self.setty(e, FLOAT)
            self.err(f"幂运算需要数值类型，实际是 {lt} 与 {rt}", e)

        if op in ("&", "|", "^", "<<", ">>"):
            if is_int(lt) and is_int(rt):
                return self.setty(e, INT)
            self.err(f"位运算 {op} 需要整数，实际是 {lt} 与 {rt}", e)

        if op in ("==", "!="):
            if is_numeric(lt) and is_numeric(rt):
                return self.setty(e, BOOL)
            if lt == rt and (is_str(lt) or is_bool(lt) or isinstance(lt, (StructT, EnumT))):
                return self.setty(e, BOOL)
            self.err(f"不能用 {op} 比较 {lt} 与 {rt}", e)

        if op in ("<", "<=", ">", ">="):
            if is_numeric(lt) and is_numeric(rt):
                return self.setty(e, BOOL)
            if is_str(lt) and is_str(rt):
                return self.setty(e, BOOL)
            self.err(f"不能用 {op} 比较 {lt} 与 {rt}", e)

        if op == "in":
            if is_str(lt) and is_str(rt):
                return self.setty(e, BOOL)
            if isinstance(rt, ListT):
                if not self.assignable(lt, rt.elem):
                    self.err(f"in 的元素类型不匹配：{lt} 不在 {rt} 中", e)
                return self.setty(e, BOOL)
            self.err(f"右侧必须是 str 或 list，实际是 {rt}", e)

        if op in ("and", "or"):
            if not is_bool(lt) or not is_bool(rt):
                self.err(f"{op} 需要两个 bool 操作数，实际是 {lt} 与 {rt}", e)
            return self.setty(e, BOOL)

        if op in ("is", "is not"):
            self.err("Velo 1.0 没有 Optional/None 值类型，因此不支持 is 比较；请用 == 或哨兵值", e)

        self.err(f"未知运算符 {op}", e)

    def check_attr(self, e: A.Attr) -> Type:
        # 枚举成员：Color.Red
        if isinstance(e.obj, A.Name) and e.obj.id in self.enums:
            info = self.enums[e.obj.id]
            if e.name not in info.variants:
                self.err(f"枚举 {info.name} 没有成员 {e.name!r}", e)
            e.enum_name = info.name
            return self.setty(e, EnumT(info.name))
        ot = self.check_expr(e.obj)
        if isinstance(ot, StructT):
            info = self.structs[ot.name]
            for fname, fty in info.fields:
                if fname == e.name:
                    e.struct_name = ot.name
                    return self.setty(e, fty)
            self.err(f"结构体 {ot.name} 没有字段 {e.name!r}", e)
        self.err(f"类型 {ot} 没有可访问的成员 {e.name!r}", e)

    def check_call(self, e: A.Call) -> Type:
        f = e.func
        if isinstance(f, A.Attr):
            objt = self.check_expr(f.obj)
            return self.check_method(objt, f.name, e)
        if not isinstance(f, A.Name):
            self.err("只能调用函数名或方法", e)
        name = f.id

        if name in self.structs:
            info = self.structs[name]
            if len(e.args) != len(info.fields):
                self.err(f"结构体 {name} 需要 {len(info.fields)} 个字段值，实际传入 {len(e.args)} 个", e)
            for i, (arg, (fname, fty)) in enumerate(zip(e.args, info.fields)):
                at = self.check_expr(arg, fty)
                self.need(at, fty, arg, f"字段 {fname}")
            return self.setty(e, StructT(name))

        if name in self.funcs:
            info = self.funcs[name]
            if len(e.args) != len(info.params):
                self.err(f"函数 {name} 需要 {len(info.params)} 个参数，实际传入 {len(e.args)} 个", e)
            for i, (arg, (pname, pty)) in enumerate(zip(e.args, info.params)):
                at = self.check_expr(arg, pty)
                self.need(at, pty, arg, f"第 {i + 1} 个参数")
            f.ty = FuncT(tuple(p for _, p in info.params), info.ret)
            return self.setty(e, info.ret)

        if name == "range":
            self.err("range() 只能用在 for 循环中", e)

        if name in BUILTIN_FUNCS:
            return self.check_builtin(name, e)

        self.err(f"未定义的函数 {name!r}", e)

    def check_builtin(self, name: str, e: A.Call) -> Type:
        aty = [self.check_expr(a) for a in e.args]
        n = len(aty)

        def need_n(k: int):
            if n != k:
                self.err(f"{name}() 需要 {k} 个参数，实际传入 {n} 个", e)

        def need_num(i: int):
            if not is_numeric(aty[i]):
                self.err(f"{name}() 第 {i + 1} 个参数需要数值，实际是 {aty[i]}", e.args[i])

        if name in ("print", "println", "eprint", "eprintln"):
            for i, t in enumerate(aty):
                if is_none(t):
                    self.err("不能输出 none", e.args[i])
                if is_list(t):
                    self.err("print 暂不支持直接输出 list，请用循环逐个输出", e.args[i])
                if isinstance(t, (StructT, EnumT)):
                    self.err("print 暂不支持直接输出结构体 / 枚举，请输出它的字段", e.args[i])
            return self.setty(e, NONE)

        if name == "len":
            need_n(1)
            t = aty[0]
            if is_str(t) or is_list(t):
                return self.setty(e, INT)
            self.err(f"len() 需要 str 或 list，实际是 {t}", e.args[0])

        if name == "utf8_len":
            need_n(1)
            if not is_str(aty[0]):
                self.err("utf8_len() 需要 str", e.args[0])
            return self.setty(e, INT)

        if name == "abs":
            need_n(1)
            need_num(0)
            return self.setty(e, FLOAT if is_float(aty[0]) else INT)

        if name in ("min", "max"):
            need_n(2)
            need_num(0)
            need_num(1)
            if is_float(aty[0]) or is_float(aty[1]):
                return self.setty(e, FLOAT)
            return self.setty(e, INT)

        if name in MATH1:
            need_n(1)
            need_num(0)
            return self.setty(e, FLOAT)

        if name in ("pow", "atan2"):
            need_n(2)
            need_num(0)
            need_num(1)
            return self.setty(e, FLOAT)

        if name in ("int", "to_int"):
            need_n(1)
            t = aty[0]
            if is_str(t) or is_numeric(t) or is_bool(t):
                return self.setty(e, INT)
            self.err(f"int() 不支持 {t}", e.args[0])

        if name in ("float", "to_float"):
            need_n(1)
            t = aty[0]
            if is_str(t) or is_numeric(t) or is_bool(t):
                return self.setty(e, FLOAT)
            self.err(f"float() 不支持 {t}", e.args[0])

        if name in ("str", "to_str"):
            need_n(1)
            t = aty[0]
            if is_none(t):
                self.err("str() 不支持 none", e.args[0])
            return self.setty(e, STR)

        if name == "panic":
            need_n(1)
            if not is_str(aty[0]):
                self.err("panic() 需要 str 信息", e.args[0])
            return self.setty(e, NONE)

        if name == "assert":
            if n < 1 or n > 2:
                self.err("assert() 需要 1~2 个参数", e)
            if not is_bool(aty[0]):
                self.err(f"assert() 的第一个参数必须是 bool，实际是 {aty[0]}", e.args[0])
            return self.setty(e, NONE)

        if name == "exit":
            need_n(1)
            if not is_int(aty[0]):
                self.err("exit() 需要 int 退出码", e.args[0])
            return self.setty(e, NONE)

        if name == "sort":
            need_n(1)
            t = aty[0]
            if not isinstance(t, ListT):
                self.err("sort() 需要 list", e.args[0])
            if not (is_int(t.elem) or is_float(t.elem) or is_str(t.elem)):
                self.err(f"sort() 不支持 {t.elem} 元素", e.args[0])
            return self.setty(e, NONE)

        if name == "reverse":
            need_n(1)
            t = aty[0]
            if not isinstance(t, ListT) or not (is_int(t.elem) or is_float(t.elem) or is_str(t.elem)):
                self.err("reverse() 需要 int/float/str 元素的 list", e.args[0])
            return self.setty(e, NONE)

        if name == "arg_count":
            need_n(0)
            return self.setty(e, INT)

        if name == "arg":
            need_n(1)
            if not is_int(aty[0]):
                self.err("arg() 需要 int 下标", e.args[0])
            return self.setty(e, STR)

        if name == "read_file":
            need_n(1)
            if not is_str(aty[0]):
                self.err("read_file() 需要文件路径（str）", e.args[0])
            return self.setty(e, STR)

        if name == "write_file":
            need_n(2)
            if not is_str(aty[0]) or not is_str(aty[1]):
                self.err("write_file(path, content) 需要两个 str 参数", e)
            return self.setty(e, INT)

        if name == "file_exists":
            need_n(1)
            if not is_str(aty[0]):
                self.err("file_exists() 需要 str 路径", e.args[0])
            return self.setty(e, BOOL)

        if name == "fill":
            need_n(2)
            if not is_int(aty[0]):
                self.err("fill(n, value) 的第一个参数必须是 int", e.args[0])
            vt = aty[1]
            if is_none(vt):
                self.err("fill() 的填充值不能是 none", e.args[1])
            if isinstance(vt, (StructT, EnumT)):
                self.err("fill() 暂不支持结构体 / 枚举作为元素", e.args[1])
            return self.setty(e, ListT(vt))

        self.err(f"未实现的内建函数 {name}", e)

    def check_method(self, objt: Type, mname: str, e: A.Call) -> Type:
        aty = [self.check_expr(a) for a in e.args]
        n = len(aty)

        if isinstance(objt, ListT):
            elem = objt.elem
            if mname == "append":
                if n != 1:
                    self.err("append() 需要 1 个参数", e)
                self.need(aty[0], elem, e.args[0], "append 参数")
                return self.setty(e, NONE)
            if mname == "pop":
                if n != 0:
                    self.err("pop() 不接受参数", e)
                return self.setty(e, elem)
            if mname == "insert":
                if n != 2:
                    self.err("insert() 需要 2 个参数", e)
                if not is_int(aty[0]):
                    self.err("insert() 第一个参数应为 int", e.args[0])
                self.need(aty[1], elem, e.args[1], "insert 参数")
                return self.setty(e, NONE)
            if mname == "remove":
                if n != 1:
                    self.err("remove() 需要 1 个参数", e)
                if not is_int(aty[0]):
                    self.err("remove() 的参数应为 int 下标", e.args[0])
                return self.setty(e, NONE)
            if mname in ("clear", "sort", "reverse"):
                if n != 0:
                    self.err(f"{mname}() 不接受参数", e)
                return self.setty(e, NONE)
            if mname == "index_of":
                if n != 1:
                    self.err("index_of() 需要 1 个参数", e)
                self.need(aty[0], elem, e.args[0], "index_of 参数")
                return self.setty(e, INT)
            if mname == "len":
                if n != 0:
                    self.err("len() 不接受参数", e)
                return self.setty(e, INT)
            if mname == "push":
                if n != 1:
                    self.err("push() 需要 1 个参数", e)
                self.need(aty[0], elem, e.args[0], "push 参数")
                return self.setty(e, NONE)
            self.err(f"list 没有方法 {mname!r}", e)

        if is_str(objt):
            if mname in ("upper", "lower", "trim", "trim_start", "trim_end"):
                if n != 0:
                    self.err(f"{mname}() 不接受参数", e)
                return self.setty(e, STR)
            if mname == "split":
                if n != 1:
                    self.err("split() 需要 1 个参数（分隔符）", e)
                if not is_str(aty[0]):
                    self.err("split() 的参数必须是 str", e.args[0])
                return self.setty(e, ListT(STR))
            if mname == "split_ws":
                if n != 0:
                    self.err("split_ws() 不接受参数", e)
                return self.setty(e, ListT(STR))
            if mname == "replace":
                if n != 2:
                    self.err("replace() 需要 2 个参数", e)
                for a in e.args:
                    pass
                return self.setty(e, STR)
            if mname in ("contains", "starts_with", "ends_with"):
                if n != 1:
                    self.err(f"{mname}() 需要 1 个参数", e)
                if not is_str(aty[0]):
                    self.err(f"{mname}() 的参数必须是 str", e.args[0])
                return self.setty(e, BOOL)
            if mname == "find":
                if n != 1:
                    self.err("find() 需要 1 个参数（要查找的子串）", e)
                if not is_str(aty[0]):
                    self.err("find() 的参数必须是 str", e.args[0])
                return self.setty(e, INT)
            if mname == "byte_at":
                if n != 1:
                    self.err("byte_at() 需要 1 个参数", e)
                if not is_int(aty[0]):
                    self.err("byte_at() 的参数必须是 int", e.args[0])
                return self.setty(e, INT)
            if mname in ("char_at",):
                if n != 1:
                    self.err("char_at() 需要 1 个参数", e)
                if not is_int(aty[0]):
                    self.err("char_at() 的参数必须是 int", e.args[0])
                return self.setty(e, STR)
            if mname == "repeat":
                if n != 1:
                    self.err("repeat() 需要 1 个参数", e)
                if not is_int(aty[0]):
                    self.err("repeat() 的参数必须是 int", e.args[0])
                return self.setty(e, STR)
            if mname == "to_int":
                if n != 0:
                    self.err("to_int() 不接受参数", e)
                return self.setty(e, INT)
            if mname == "to_float":
                if n != 0:
                    self.err("to_float() 不接受参数", e)
                return self.setty(e, FLOAT)
            if mname == "bytes":
                if n != 0:
                    self.err("bytes() 不接受参数", e)
                return self.setty(e, INT)
            if mname == "join":
                if n != 1:
                    self.err("join() 需要 1 个参数（list[str]）", e)
                t = aty[0]
                if not (isinstance(t, ListT) and is_str(t.elem)):
                    self.err(f"join() 需要 list[str]，实际是 {t}", e.args[0])
                return self.setty(e, STR)
            self.err(f"str 没有方法 {mname!r}", e)

        self.err(f"类型 {objt} 没有方法 {mname!r}", e)


def check(module: A.Module, filename: str = "<velo>", source: str = "") -> Checker:
    ck = Checker(module, filename, source)
    ck.run()
    return ck
