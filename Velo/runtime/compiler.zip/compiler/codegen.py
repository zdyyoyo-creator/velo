"""Velo -> C 代码生成器。

所有权模型（针对 str / list 这类引用计数类型）：
  * 每个表达式求值后标记为 owned（持有一次新引用）或 borrowed（借用）。
  * owned 的结果被物化到块内临时变量，块结束时统一 release；
    若所有权被移交给变量 / 返回值，则标记为 moved，不再 release。
  * 变量声明 / 赋值：拥有值则转移，借用值则 retain。
  * 作用域退出与 return 之前，释放全部本地变量与临时变量。
数值类型完全内联，不产生任何额外调用。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import ast_nodes as A
from .checker import Checker, EnumInfo, FuncInfo, StructInfo
from .types import (
    BOOL, BYTE, F32, FLOAT, I8, I16, I32, I64, INT, NONE, STR,
    U8, U16, U32, U64, USIZE, EnumT, ListT, Prim, StructT, Type,
    is_bool, is_float, is_int, is_list, is_none, is_numeric, is_rc, is_str,
)


@dataclass
class Val:
    expr: str
    ty: Type
    owned: bool = False
    temp: Optional[str] = None


def fmt_float(v: float) -> str:
    if v != v:
        return "(0.0/0.0)"
    if v in (float("inf"), float("-inf")):
        return "HUGE_VAL" if v > 0 else "(-HUGE_VAL)"
    s = repr(v)
    if "e" in s or "E" in s or "." in s:
        return s
    return s + ".0"


def c_escape(data: bytes) -> str:
    """把字节串转成 C 字符串字面量内容。

    合法的 UTF-8 序列原样保留（配合 /utf-8 编译选项，生成代码可读），
    控制字符与非法字节用三位八进制转义。
    """
    out: List[str] = []
    i = 0
    n = len(data)
    while i < n:
        b = data[i]
        if b == 0x22:
            out.append('\\"')
            i += 1
        elif b == 0x5C:
            out.append("\\\\")
            i += 1
        elif 0x20 <= b <= 0x7E:
            out.append(chr(b))
            i += 1
        elif b >= 0x80:
            k = 1
            if (b & 0xE0) == 0xC0:
                k = 2
            elif (b & 0xF0) == 0xE0:
                k = 3
            elif (b & 0xF8) == 0xF0:
                k = 4
            try:
                out.append(data[i:i + k].decode("utf-8"))
                i += k
            except UnicodeDecodeError:
                out.append("\\%03o" % b)
                i += 1
        else:
            out.append("\\%03o" % b)
            i += 1
    return "".join(out)


LIST_C = {
    INT: ("vl_i64list", "i64"),
    I64: ("vl_i64list", "i64"),
    I32: ("vl_i32list", "i32"),
    I16: ("vl_i16list", "i16"),
    I8: ("vl_i8list", "i8"),
    U64: ("vl_u64list", "u64"),
    U32: ("vl_u32list", "u32"),
    U16: ("vl_u16list", "u16"),
    U8: ("vl_u8list", "u8"),
    BYTE: ("vl_u8list", "u8"),
    USIZE: ("vl_u64list", "u64"),
    FLOAT: ("vl_f64list", "f64"),
    F32: ("vl_f64list", "f64"),
    BOOL: ("vl_boollist", "bool"),
    STR: ("vl_strlist", "str"),
}


class CodeGen:
    def __init__(self, module: A.Module, ck: Checker, filename: str = "<velo>", source: str = ""):
        self.module = module
        self.ck = ck
        self.filename = filename
        self.source = source

        self.out: List[str] = []
        self.indent = 0
        self.temp_stack: List[List[dict]] = []
        self.local_stack: List[List[Tuple[str, Type]]] = []
        self.tmp_n = 0
        self.lbl_n = 0
        self.str_pool: Dict[bytes, str] = {}
        self.str_order: List[Tuple[str, bytes]] = []
        self.func_bodies: List[str] = []
        self.protos: List[str] = []
        self.needs_math = False
        self.main_body: List[str] = []
        self.global_inits: List[str] = []
        self.loop_stack: List[Tuple[int, int]] = []
        self.cur_ret: Type = NONE

    # ------------------------------------------------------------ 输出工具
    def emit(self, s: str = ""):
        self.out.append(("    " * self.indent + s) if s else "")

    def fresh(self, prefix: str = "t") -> str:
        self.tmp_n += 1
        return f"{prefix}{self.tmp_n}"

    def label(self, prefix: str = "L") -> str:
        self.lbl_n += 1
        return f"{prefix}{self.lbl_n}"

    def fn_name(self, name: str) -> str:
        return f"vl_fn_{name}"

    # ------------------------------------------------------------ 类型映射
    def ctype(self, t: Type) -> str:
        if t == INT or t == I64:
            return "int64_t"
        if t == I32:
            return "int32_t"
        if t == I16:
            return "int16_t"
        if t == I8:
            return "int8_t"
        if t == U64 or t == USIZE:
            return "uint64_t"
        if t == U32:
            return "uint32_t"
        if t == U16:
            return "uint16_t"
        if t == U8 or t == BYTE:
            return "uint8_t"
        if t == FLOAT:
            return "double"
        if t == F32:
            return "float"
        if t == BOOL:
            return "bool"
        if t == STR:
            return "vl_str*"
        if isinstance(t, ListT):
            name = LIST_C.get(t.elem)
            if name is None:
                raise RuntimeError(f"不支持作为列表元素：{t.elem}")
            return name[0] + "*"
        if isinstance(t, StructT):
            return f"vl_{t.name}"
        if isinstance(t, EnumT):
            return f"vl_{t.name}"
        if t == NONE:
            return "void"
        raise RuntimeError(f"无法映射类型 {t}")

    def list_cname(self, t: ListT) -> str:
        name = LIST_C.get(t.elem)
        if name is None:
            raise RuntimeError(f"不支持作为列表元素：{t.elem}")
        return name[0]

    def is_rc_type(self, t: Type) -> bool:
        return is_rc(t)

    def retain_expr(self, t: Type, expr: str) -> str:
        if t == STR:
            return f"vl_str_retain({expr})"
        if isinstance(t, ListT):
            return f"{self.list_cname(t)}_retain({expr})"
        return expr

    def release_expr(self, t: Type, expr: str) -> str:
        if t == STR:
            return f"vl_str_release({expr})"
        if isinstance(t, ListT):
            return f"{self.list_cname(t)}_release({expr})"
        return f"(void)({expr})"

    # ------------------------------------------------------------ 临时变量
    def cur_temps(self) -> List[dict]:
        return self.temp_stack[-1]

    def new_temp(self, ty: Type, expr: str, owned: bool = True) -> str:
        ct = self.ctype(ty)
        name = self.fresh("t")
        self.emit(f"{ct} {name} = {expr};")
        self.cur_temps().append({"name": name, "ty": ty, "moved": False, "owned": owned})
        return name

    def mark_moved(self, name: str):
        for frame in reversed(self.temp_stack):
            for t in frame:
                if t["name"] == name:
                    t["moved"] = True
                    return

    def flush_temps(self):
        frame = self.cur_temps()
        for t in reversed(frame):
            if t["owned"] and not t["moved"] and is_rc(t["ty"]):
                self.emit(self.release_expr(t["ty"], t["name"]) + ";")
        frame.clear()

    def start_block(self):
        self.temp_stack.append([])

    def end_block(self):
        self.flush_temps()
        self.temp_stack.pop()

    # ------------------------------------------------------------ 字符串池
    def str_const(self, data: bytes) -> str:
        if data in self.str_pool:
            return self.str_pool[data]
        name = f"vlS{len(self.str_pool)}"
        self.str_pool[data] = name
        self.str_order.append((name, data))
        return name

    # ============================================================ 入口
    def generate(self) -> str:
        body = self.module.body
        # 顶层语句与全局变量
        top_stmts = [st for st in body if not isinstance(st, (A.FuncDef, A.StructDef, A.EnumDef, A.Import))]
        top_vars = [st for st in top_stmts if isinstance(st, A.VarDecl)]

        # 全局变量声明
        gdecls = []
        for st in top_vars:
            ct = self.ctype(st.ty)
            gdecls.append(f"static {ct} g_{st.name};")

        # 函数
        for st in body:
            if isinstance(st, A.FuncDef):
                info = self.ck.funcs[st.name]
                self.gen_proto(info)
        for st in body:
            if isinstance(st, A.FuncDef) and not st.is_extern:
                info = self.ck.funcs[st.name]
                self.func_bodies.append(self.gen_function(info))

        # main
        self.out = self.main_body
        self.indent = 1
        self.start_block()
        self.local_stack.append([])
        for st in top_vars:
            self.gen_global_init(st)
        for st in top_stmts:
            if isinstance(st, A.VarDecl):
                continue
            self.gen_stmt(st)
        self.local_stack.pop()
        self.end_block()
        main_lines = self.out
        self.out = []

        # 组装
        parts: List[str] = []
        parts.append("/* Generated by the Velo compiler. Do not edit by hand. */")
        parts.append(f"/* 源文件: {self.filename} */")
        parts.append('#include "velo_rt.h"')
        parts.append('/* 直接包含运行时实现：单一编译单元让编译器能做全程序内联与优化 */')
        parts.append('#include "velo_rt.c"')
        parts.append("")
        # 结构体 / 枚举
        if self.struct_defs:
            parts.extend(self.struct_defs)
        # 字符串常量池
        if self.str_order:
            parts.append("/* ---- 字符串常量池（引用计数固定为极大值，永不释放） ---- */")
            for name, data in self.str_order:
                esc = c_escape(data)
                parts.append(f'static char {name}_b[] = "{esc}";')
                parts.append(f"static vl_str {name}_o = {{ 2000000000LL, {len(data)}LL, {name}_b }};")
                parts.append(f"static vl_str* {name} = &{name}_o;")
            parts.append("")
        # 全局变量
        if gdecls:
            parts.append("/* ---- 全局变量 ---- */")
            parts.extend(gdecls)
            parts.append("")
        # 函数原型
        if self.protos:
            parts.append("/* ---- 函数原型 ---- */")
            parts.extend(self.protos)
            parts.append("")
        parts.extend(self.func_bodies)
        # main
        parts.append("int main(int argc, char** argv) {")
        parts.append("    vl_rt_init();")
        parts.append("    vl_argc = (int32_t)argc;")
        parts.append("    vl_argv = argv;")
        parts.extend(main_lines)
        if self.ck.has_user_main:
            ret = self.ck.funcs["main"].ret
            if is_none(ret):
                parts.append("    vl_fn_main();")
                parts.append("    vl_rt_shutdown();")
                parts.append("    return 0;")
            else:
                parts.append("    int _vrc = (int)vl_fn_main();")
                parts.append("    vl_rt_shutdown();")
                parts.append("    return _vrc;")
        else:
            parts.append("    vl_rt_shutdown();")
            parts.append("    return 0;")
        parts.append("}")
        parts.append("")
        return "\n".join(parts)

    def gen_proto(self, info: FuncInfo):
        ret = self.ctype(info.ret)
        params = ", ".join(f"{self.ctype(t)} a{i}" for i, (_, t) in enumerate(info.params))
        if not params:
            params = "void"
        if info.is_extern:
            self.protos.append(f"extern {ret} {info.name}({params});")
        else:
            self.protos.append(f"static {ret} {self.fn_name(info.name)}({params});")

    struct_defs: List[str] = []

    def gen_structs(self):
        defs: List[str] = []
        for name, info in self.ck.structs.items():
            fields = " ".join(f"{self.ctype(fty)} {fname};" for fname, fty in info.fields)
            defs.append(f"typedef struct vl_{name} {{ {fields} }} vl_{name};")
        for name, info in self.ck.enums.items():
            vs = ", ".join(f"vl_{name}_{v}" for v in info.variants)
            defs.append(f"typedef enum {{ {vs} }} vl_{name};")
        self.struct_defs = defs

    def gen_global_init(self, st: A.VarDecl):
        v = self.gen_expr(st.value)
        if not is_rc(st.ty):
            self.emit(f"g_{st.name} = {v.expr};")
        else:
            if v.owned:
                self.mark_moved(v.temp or "")
                self.emit(f"g_{st.name} = {v.expr};")
            else:
                self.emit(f"g_{st.name} = {self.retain_expr(st.ty, v.expr)};")

    # ============================================================ 函数
    def gen_function(self, info: FuncInfo) -> str:
        self.out = []
        self.indent = 0
        self.start_block()
        self.local_stack.append([])
        ret = self.ctype(info.ret)
        params = ", ".join(f"{self.ctype(t)} a{i}" for i, (_, t) in enumerate(info.params))
        head = f"static {ret} {self.fn_name(info.name)}({params if params else 'void'}) {{"
        self.emit(head)
        self.indent = 1
        # 参数别名：RC 类型在入口 retain 一次，保证函数内可自由赋值，
        # 并在函数返回时统一释放。
        for i, (pname, pty) in enumerate(info.params):
            if is_rc(pty):
                self.emit(f"{self.ctype(pty)} {pname} = {self.retain_expr(pty, f'a{i}')};")
                self.local_stack[-1].append((pname, pty))
            else:
                self.emit(f"{self.ctype(pty)} {pname} = a{i};")
        self.cur_ret = info.ret
        for st in info.node.body:
            self.gen_stmt(st)
        # 兜底 return：静态检查已保证所有路径都有返回值，这里仅避免 C 编译器告警
        if is_none(info.ret):
            self.emit("return;")
        else:
            self.emit(f"return {self.zero_value(info.ret)};")
        self.local_stack.pop()
        self.end_block()
        self.indent = 0
        self.emit("}")
        body = self.out
        return "\n".join(body) + "\n"

    def zero_value(self, ty: Type) -> str:
        if is_str(ty):
            return "NULL"
        if isinstance(ty, ListT):
            return "NULL"
        if isinstance(ty, (StructT, EnumT)):
            return "{0}"
        if is_float(ty):
            return "0.0"
        return "0"

    # ============================================================ 语句
    def acq(self, ty: Type, v: Val, name: str):
        """把值 v 绑定到新变量 name（取得所有权）。"""
        ct = self.ctype(ty)
        if not is_rc(ty):
            self.emit(f"{ct} {name} = {v.expr};")
            return
        if v.owned:
            if v.temp:
                self.mark_moved(v.temp)
            self.emit(f"{ct} {name} = {v.expr};")
        else:
            self.emit(f"{ct} {name} = {self.retain_expr(ty, v.expr)};")

    def gen_stmt(self, st: A.Node):
        if isinstance(st, A.VarDecl):
            if st.value is None:
                self.gen_default_init(st.ty, st.name)
            else:
                v = self.gen_expr(st.value)
                self.acq(st.ty, v, st.name)
            self.local_stack[-1].append((st.name, st.ty))

        elif isinstance(st, A.Assign):
            v = self.gen_expr(st.value)
            self.gen_assign(st.target, v)

        elif isinstance(st, A.AugAssign):
            self.gen_augassign(st)

        elif isinstance(st, A.ExprStmt):
            v = self.gen_expr(st.value)
            if is_rc(v.ty) and v.owned:
                pass

        elif isinstance(st, A.Return):
            self.gen_return(st)

        elif isinstance(st, A.If):
            self.gen_if(st)

        elif isinstance(st, A.While):
            self.gen_while(st)

        elif isinstance(st, A.For):
            self.gen_for(st)

        elif isinstance(st, A.Break):
            self.gen_break_cleanup()
            self.emit("break;")

        elif isinstance(st, A.Continue):
            self.gen_continue_cleanup()
            self.emit("continue;")

        elif isinstance(st, A.Pass):
            self.emit(";")

        elif isinstance(st, (A.Import,)):
            pass

        else:
            raise RuntimeError(f"无法生成语句 {type(st).__name__}")

    def gen_loop_cleanup(self):
        """break / continue 之前释放本循环体内持有的引用计数资源。"""
        if not self.loop_stack:
            return
        ldepth, tdepth = self.loop_stack[-1]
        for fi in range(len(self.temp_stack) - 1, tdepth - 1, -1):
            for t in reversed(self.temp_stack[fi]):
                if t["owned"] and not t["moved"] and is_rc(t["ty"]):
                    self.emit(self.release_expr(t["ty"], t["name"]) + ";")
        for fi in range(len(self.local_stack) - 1, ldepth - 1, -1):
            for name, ty in reversed(self.local_stack[fi]):
                if is_rc(ty):
                    self.emit(self.release_expr(ty, name) + ";")

    def release_all_locals(self):
        for frame in reversed(self.local_stack):
            for name, ty in reversed(frame):
                if is_rc(ty):
                    self.emit(self.release_expr(ty, name) + ";")

    def gen_break_cleanup(self):
        self.gen_loop_cleanup()

    def gen_continue_cleanup(self):
        self.gen_loop_cleanup()

    def gen_default_init(self, ty: Type, name: str):
        ct = self.ctype(ty)
        if isinstance(ty, (StructT, EnumT)):
            self.emit(f"{ct} {name} = {{0}};")
        elif is_rc(ty):
            self.emit(f"{ct} {name} = NULL;")
        else:
            self.emit(f"{ct} {name} = 0;")

    def gen_assign(self, target: A.Node, v: Val):
        if isinstance(target, A.Name):
            name = target.id
            ty = target.ty
            if not is_rc(ty):
                self.emit(f"{name} = {v.expr};")
                return
            tmp = self.fresh("old")
            ct = self.ctype(ty)
            self.emit(f"{ct} {tmp} = {name};")
            if v.owned:
                if v.temp:
                    self.mark_moved(v.temp)
                self.emit(f"{name} = {v.expr};")
            else:
                self.emit(f"{name} = {self.retain_expr(ty, v.expr)};")
            self.emit(f"{self.release_expr(ty, tmp)};")

        elif isinstance(target, A.Index):
            obj = self.gen_expr(target.obj)
            idx = self.gen_expr(target.index)
            oty = target.obj.ty
            elem = oty.elem
            lc = self.list_cname(oty)
            if is_rc(elem):
                if v.owned:
                    if v.temp:
                        self.mark_moved(v.temp)
                    self.emit(f"{lc}_set({obj.expr}, {idx.expr}, {v.expr});")
                else:
                    self.emit(f"{lc}_set({obj.expr}, {idx.expr}, {v.expr});")
            else:
                self.emit(f"{lc}_set({obj.expr}, {idx.expr}, {v.expr});")

        elif isinstance(target, A.Attr):
            obj = self.gen_expr(target.obj)
            self.emit(f"{obj.expr}.{target.name} = {v.expr};")

        else:
            raise RuntimeError("不支持的赋值目标")

    def gen_augassign(self, st: A.AugAssign):
        t = st.target
        ty = t.ty
        if isinstance(t, A.Name):
            v = self.gen_expr(st.value)
            if is_str(ty):
                if st.op != "+":
                    raise RuntimeError("字符串仅支持 +=")
                newv = self.new_temp(STR, f"vl_str_concat({t.id}, {v.expr})")
                old = self.fresh("old")
                self.emit(f"vl_str* {old} = {t.id};")
                self.emit(f"{t.id} = {newv};")
                self.mark_moved(newv)
                self.emit(f"vl_str_release({old});")
                return
            if isinstance(ty, ListT):
                raise RuntimeError("list 不支持复合赋值")
            self.emit(f"{t.id} = {t.id} {st.op} ({v.expr});")
            return
        obj = self.gen_expr(t.obj) if isinstance(t, (A.Index, A.Attr)) else None
        v = self.gen_expr(st.value)
        if isinstance(t, A.Index):
            oty = t.obj.ty
            lc = self.list_cname(oty)
            idx = self.gen_expr(t.index)
            cur = f"{lc}_get({obj.expr}, {idx.expr})"
            self.emit(f"{lc}_set({obj.expr}, {idx.expr}, {cur} {st.op} ({v.expr}));")
        elif isinstance(t, A.Attr):
            self.emit(f"{obj.expr}.{t.name} = {obj.expr}.{t.name} {st.op} ({v.expr});")

    def gen_if(self, st: A.If):
        v = self.gen_expr(st.cond)
        self.emit(f"if ({v.expr}) {{")
        self.indent += 1
        self.start_block()
        self.local_stack.append([])
        for s in st.body:
            self.gen_stmt(s)
        self.local_stack.pop()
        self.end_block()
        self.indent -= 1
        if st.orelse:
            self.emit("} else {")
            self.indent += 1
            self.start_block()
            self.local_stack.append([])
            for s in st.orelse:
                self.gen_stmt(s)
            self.local_stack.pop()
            self.end_block()
            self.indent -= 1
        self.emit("}")

    def gen_while(self, st: A.While):
        self.emit("{")
        self.indent += 1
        self.start_block()
        self.local_stack.append([])
        self.emit("for (;;) {")
        self.indent += 1
        self.start_block()
        c = self.gen_expr(st.cond)
        ctmp = self.fresh("c")
        self.emit(f"bool {ctmp} = (bool)({c.expr});")
        self.flush_temps()
        self.emit(f"if (!{ctmp}) break;")
        self.local_stack.append([])
        self.loop_stack.append((len(self.local_stack), len(self.temp_stack)))
        for s in st.body:
            self.gen_stmt(s)
        self.loop_stack.pop()
        self.local_stack.pop()
        self.end_block()
        self.emit("}")
        self.indent -= 1
        self.local_stack.pop()
        self.end_block()
        self.emit("}")

    def gen_for(self, st: A.For):
        if getattr(st, "iter_kind", None) == "range":
            self.gen_range_for(st)
            return
        # 遍历 list
        lv = self.gen_expr(st.iter)
        oty = st.iter.ty
        lc = self.list_cname(oty)
        elem = oty.elem
        self.emit("{")
        self.indent += 1
        self.start_block()
        self.local_stack.append([])
        iv = self.fresh("i")
        nv = self.fresh("n")
        self.emit(f"{lc}* _l = {lv.expr};")
        self.emit(f"int64_t {nv} = {lc}_len(_l);")
        self.emit(f"for (int64_t {iv} = 0; {iv} < {nv}; {iv}++) {{")
        self.indent += 1
        self.start_block()
        self.local_stack.append([])
        if is_rc(elem):
            self.emit(f"{self.ctype(elem)} {st.target} = {self.retain_expr(elem, f'{lc}_get(_l, {iv})')};")
        else:
            self.emit(f"{self.ctype(elem)} {st.target} = {lc}_get(_l, {iv});")
        self.local_stack[-1].append((st.target, elem))
        self.loop_stack.append((len(self.local_stack), len(self.temp_stack)))
        for s in st.body:
            self.gen_stmt(s)
        self.loop_stack.pop()
        if is_rc(elem):
            self.emit(f"{self.release_expr(elem, st.target)};")
        self.local_stack.pop()
        self.end_block()
        self.indent -= 1
        self.emit("}")
        self.local_stack.pop()
        self.end_block()
        self.indent -= 1
        self.emit("}")

    def gen_range_for(self, st: A.For):
        call = st.iter
        args = call.args
        vals = [self.gen_expr(a) for a in args]
        self.emit("{")
        self.indent += 1
        self.start_block()
        self.local_stack.append([])
        if len(vals) == 1:
            self.emit(f"int64_t _stop = {vals[0].expr};")
            self.emit("int64_t _start = 0;")
            self.emit("int64_t _step = 1;")
        elif len(vals) == 2:
            self.emit(f"int64_t _start = {vals[0].expr};")
            self.emit(f"int64_t _stop = {vals[1].expr};")
            self.emit("int64_t _step = 1;")
        else:
            self.emit(f"int64_t _start = {vals[0].expr};")
            self.emit(f"int64_t _stop = {vals[1].expr};")
            self.emit(f"int64_t _step = {vals[2].expr};")
        self.emit(f"for (int64_t {st.target} = _start; "
                  f"(_step > 0) ? ({st.target} < _stop) : ({st.target} > _stop); "
                  f"{st.target} += _step) {{")
        self.indent += 1
        self.start_block()
        self.local_stack.append([])
        self.loop_stack.append((len(self.local_stack), len(self.temp_stack)))
        for s in st.body:
            self.gen_stmt(s)
        self.loop_stack.pop()
        self.local_stack.pop()
        self.end_block()
        self.indent -= 1
        self.emit("}")
        self.local_stack.pop()
        self.end_block()
        self.indent -= 1
        self.emit("}")

    loop_stack: List = []

    def gen_return(self, st: A.Return):
        ret_ty = self.cur_ret
        if st.value is None:
            self.flush_temps()
            self.release_all_locals()
            self.emit("return;")
            return
        v = self.gen_expr(st.value)
        rn = self.fresh("_r")
        if is_rc(ret_ty):
            if v.owned:
                if v.temp:
                    self.mark_moved(v.temp)
                self.emit(f"{self.ctype(ret_ty)} {rn} = {v.expr};")
            else:
                self.emit(f"{self.ctype(ret_ty)} {rn} = {self.retain_expr(ret_ty, v.expr)};")
        else:
            self.emit(f"{self.ctype(ret_ty)} {rn} = {v.expr};")
        self.flush_temps()
        self.release_all_locals()
        self.emit(f"return {rn};")

    # ============================================================ 表达式
    def gen_expr(self, e: A.Node) -> Val:
        ty = e.ty

        if isinstance(e, A.IntLit):
            return Val(str(e.value), ty)
        if isinstance(e, A.FloatLit):
            return Val(fmt_float(e.value), ty)
        if isinstance(e, A.BoolLit):
            return Val("true" if e.value else "false", ty)
        if isinstance(e, A.NoneLit):
            raise RuntimeError("None 不能作为表达式值使用")

        if isinstance(e, A.StrLit):
            return self.gen_strlit(e)

        if isinstance(e, A.Name):
            return Val(e.id, ty)

        if isinstance(e, A.BinOp):
            return self.gen_binop(e)

        if isinstance(e, A.UnaryOp):
            v = self.gen_expr(e.operand)
            if e.op == "not":
                return Val(f"(!({v.expr}))", ty)
            if e.op == "-":
                if is_int(v.ty):
                    return Val(f"(-({v.expr}))", ty)
                return Val(f"(-({v.expr}))", ty)
            if e.op == "+":
                return Val(f"(+({v.expr}))", ty)
            if e.op == "~":
                return Val(f"(~({v.expr}))", ty)
            raise RuntimeError(f"未知一元运算 {e.op}")

        if isinstance(e, A.Call):
            return self.gen_call(e)

        if isinstance(e, A.Attr):
            return self.gen_attr(e)

        if isinstance(e, A.Index):
            o = self.gen_expr(e.obj)
            i = self.gen_expr(e.index)
            oty = e.obj.ty
            if isinstance(oty, ListT):
                lc = self.list_cname(oty)
                if is_rc(oty.elem):
                    # 列表元素是借用语义：物化到临时变量，但不释放
                    name = self.new_temp(oty.elem, f"{lc}_get({o.expr}, {i.expr})", owned=False)
                    return Val(name, ty, owned=False)
                return Val(f"{lc}_get({o.expr}, {i.expr})", ty)
            if is_str(oty):
                name = self.new_temp(STR, f"vl_str_char_at({o.expr}, {i.expr})")
                return Val(name, STR, owned=True, temp=name)
            raise RuntimeError("非法下标")

        if isinstance(e, A.SliceExpr):
            o = self.gen_expr(e.obj)
            lo = self.gen_expr(e.lower).expr if e.lower is not None else "0"
            hi = self.gen_expr(e.upper).expr if e.upper is not None else f"vl_str_len({o.expr})"
            name = self.new_temp(STR, f"vl_str_slice({o.expr}, {lo}, {hi})")
            return Val(name, STR, owned=True, temp=name)

        if isinstance(e, A.ListLit):
            return self.gen_listlit(e)

        if isinstance(e, A.CondExpr):
            c = self.gen_expr(e.cond)
            if self.is_pure(e.then) and self.is_pure(e.other):
                a = self.gen_expr(e.then)
                b = self.gen_expr(e.other)
                return Val(f"(({c.expr}) ? ({a.expr}) : ({b.expr}))", ty)
            ct = self.ctype(ty)
            nm = self.fresh("cx")
            self.emit(f"{ct} {nm};")
            self.emit(f"if ({c.expr}) {{")
            self.indent += 1
            self.start_block()
            a = self.gen_expr(e.then)
            self.emit(f"{nm} = {a.expr};")
            self.end_block()
            self.indent -= 1
            self.emit("} else {")
            self.indent += 1
            self.start_block()
            b = self.gen_expr(e.other)
            self.emit(f"{nm} = {b.expr};")
            self.end_block()
            self.indent -= 1
            self.emit("}")
            return Val(nm, ty)

        raise RuntimeError(f"无法生成表达式 {type(e).__name__}")

    def gen_strlit(self, e: A.StrLit) -> Val:
        if len(e.parts) == 1 and e.parts[0][0] == "lit":
            data = e.parts[0][1].encode("utf-8")
            return Val(self.str_const(data), STR)
        # 插值：使用构建器一次分配
        sb = self.fresh("sb")
        self.emit(f"vl_sb {sb};")
        self.emit(f"vl_sb_init(&{sb});")
        for kind, val in e.parts:
            if kind == "lit":
                if val:
                    self.emit(f'vl_sb_put_cstr(&{sb}, "{c_escape(val.encode("utf-8"))}");')
                continue
            v = self.gen_expr(val)
            if is_str(v.ty):
                self.emit(f"vl_sb_put_str(&{sb}, {v.expr});")
            elif is_bool(v.ty):
                self.emit(f"vl_sb_put_bool(&{sb}, {v.expr});")
            elif is_float(v.ty):
                self.emit(f"vl_sb_put_f64(&{sb}, (double)({v.expr}));")
            elif is_int(v.ty):
                self.emit(f"vl_sb_put_i64(&{sb}, (int64_t)({v.expr}));")
            else:
                raise RuntimeError("插值表达式类型不受支持")
        name = self.new_temp(STR, f"vl_sb_finish(&{sb})")
        return Val(name, STR, owned=True, temp=name)

    def gen_listlit(self, e: A.ListLit) -> Val:
        ty = e.ty
        elem = ty.elem
        lc = self.list_cname(ty)
        cap = str(len(e.elems))
        name = self.new_temp(ty, f"{lc}_with_capacity({cap})")
        for el in e.elems:
            v = self.gen_expr(el)
            if is_rc(elem):
                if v.owned:
                    if v.temp:
                        self.mark_moved(v.temp)
                    self.emit(f"{lc}_push({name}, {v.expr});")
                else:
                    self.emit(f"{lc}_push({name}, {self.retain_expr(elem, v.expr)});")
            else:
                self.emit(f"{lc}_push({name}, {v.expr});")
        return Val(name, ty, owned=True, temp=name)

    def gen_attr(self, e: A.Attr) -> Val:
        if hasattr(e, "enum_name"):
            return Val(f"vl_{e.enum_name}_{e.name}", e.ty)
        o = self.gen_expr(e.obj)
        return Val(f"({o.expr}).{e.name}", e.ty)

    def is_pure(self, e: A.Node) -> bool:
        """该表达式求值是否不需要生成额外语句（可安全放入 && / || 右侧）。"""
        if isinstance(e, (A.IntLit, A.FloatLit, A.BoolLit, A.Name)):
            return True
        if isinstance(e, A.NoneLit):
            return True
        if isinstance(e, A.BinOp):
            return self.is_pure(e.left) and self.is_pure(e.right)
        if isinstance(e, A.UnaryOp):
            return self.is_pure(e.operand)
        if isinstance(e, A.Attr):
            if hasattr(e, "enum_name"):
                return True
            return self.is_pure(e.obj)
        if isinstance(e, A.Index):
            ot = e.obj.ty
            if isinstance(ot, ListT) and not is_rc(ot.elem):
                return self.is_pure(e.obj) and self.is_pure(e.index)
            return False
        if isinstance(e, A.Call):
            f = e.func
            if isinstance(f, A.Name) and f.id in (
                    "len", "abs", "min", "max", "int", "to_int", "float", "to_float",
                    "utf8_len", "arg_count", "file_exists", "sqrt", "pow"):
                return all(self.is_pure(a) for a in e.args)
            return False
        return False

    def gen_binop(self, e: A.BinOp) -> Val:
        op = e.op
        ty = e.ty

        if op in ("and", "or"):
            a = self.gen_expr(e.left)
            if self.is_pure(e.right):
                b = self.gen_expr(e.right)
                c_op = "&&" if op == "and" else "||"
                return Val(f"(({a.expr}) {c_op} ({b.expr}))", ty)
            # 右侧需要生成语句时，必须显式短路，避免无条件求值
            cname = self.fresh("sc")
            self.emit(f"bool {cname} = (bool)({a.expr});")
            self.emit(f"if ({'' if op == 'and' else '!'}{cname}) {{")
            self.indent += 1
            self.start_block()
            b = self.gen_expr(e.right)
            self.emit(f"{cname} = (bool)({b.expr});")
            self.end_block()
            self.indent -= 1
            self.emit("}")
            return Val(cname, BOOL)

        if op == "in":
            a = self.gen_expr(e.left)
            b = self.gen_expr(e.right)
            bt = e.right.ty
            if is_str(bt):
                return Val(f"vl_str_contains({b.expr}, {a.expr})", ty)
            lc = self.list_cname(bt)
            return Val(f"({lc}_index_of({b.expr}, {a.expr}) >= 0)", ty)

        a = self.gen_expr(e.left)
        b = self.gen_expr(e.right)
        lt, rt = e.left.ty, e.right.ty

        if op == "+" and is_str(lt):
            name = self.new_temp(STR, f"vl_str_concat({a.expr}, {b.expr})")
            return Val(name, STR, owned=True, temp=name)

        if op in ("==", "!=", "<", "<=", ">", ">="):
            cop = op
            if is_str(lt):
                fname = {"==": "vl_str_eq", "!=": "!vl_str_eq", "<": "vl_str_lt",
                         "<=": "vl_str_le", ">": "vl_str_gt", ">=": "vl_str_ge"}[op]
                if op == "!=":
                    return Val(f"(!vl_str_eq({a.expr}, {b.expr}))", ty)
                return Val(f"{fname}({a.expr}, {b.expr})", ty)
            return Val(f"(({a.expr}) {cop} ({b.expr}))", ty)

        if op == "/":
            self.needs_math = True
            return Val(f"(((double)({a.expr})) / ((double)({b.expr})))", FLOAT)

        if op == "//":
            if is_int(lt) and is_int(rt):
                return Val(f"vl_idiv((int64_t)({a.expr}), (int64_t)({b.expr}))", ty)
            self.needs_math = True
            return Val(f"floor((double)({a.expr}) / (double)({b.expr}))", ty)

        if op == "%":
            if is_int(lt) and is_int(rt):
                return Val(f"vl_imod((int64_t)({a.expr}), (int64_t)({b.expr}))", ty)
            self.needs_math = True
            return Val(f"fmod((double)({a.expr}), (double)({b.expr}))", ty)

        if op == "**":
            if is_int(lt) and is_int(rt):
                return Val(f"vl_ipow((int64_t)({a.expr}), (int64_t)({b.expr}))", ty)
            self.needs_math = True
            return Val(f"pow((double)({a.expr}), (double)({b.expr}))", ty)

        if op in ("&", "|", "^", "<<", ">>"):
            return Val(f"(({a.expr}) {op} ({b.expr}))", ty)

        if op in ("+", "-", "*"):
            return Val(f"(({a.expr}) {op} ({b.expr}))", ty)

        raise RuntimeError(f"未知二元运算 {op}")

    # ------------------------------------------------------------ 调用
    def gen_args(self, args: List[A.Node]) -> List[Val]:
        return [self.gen_expr(a) for a in args]

    def gen_call(self, e: A.Call) -> Val:
        f = e.func
        if isinstance(f, A.Attr):
            return self.gen_method_call(e, f)

        name = f.id
        if name in self.ck.structs:
            info = self.ck.structs[name]
            vals = self.gen_args(e.args)
            nm = self.fresh("st")
            ct = f"vl_{name}"
            self.emit(f"{ct} {nm};")
            for (fname, fty), v in zip(info.fields, vals):
                self.emit(f"{nm}.{fname} = {v.expr};")
            return Val(nm, e.ty)

        if name in self.ck.funcs:
            info = self.ck.funcs[name]
            vals = self.gen_args(e.args)
            argstr = ", ".join(v.expr for v in vals)
            callee = info.name if info.is_extern else self.fn_name(info.name)
            call = f"{callee}({argstr})"
            if is_rc(info.ret):
                nm = self.new_temp(info.ret, call)
                return Val(nm, info.ret, owned=True, temp=nm)
            if is_none(info.ret):
                self.emit(call + ";")
                return Val("0", NONE)
            return Val(call, info.ret)

        return self.gen_builtin(e, name)

    def gen_builtin(self, e: A.Call, name: str) -> Val:
        ty = e.ty
        if name in ("print", "println", "eprint", "eprintln"):
            to_err = name in ("eprint", "eprintln")
            pre = "vl_err_" if to_err else "vl_out_"
            vals = self.gen_args(e.args)
            for i, v in enumerate(vals):
                if i > 0 and not to_err:
                    self.emit("vl_out_space();")
                elif i > 0 and to_err:
                    self.emit('vl_err_cstr(" ");')
                self.emit(self.out_call(v.ty, v.expr, to_err) )
            if name in ("println", "eprintln"):
                self.emit("vl_err_endl();" if to_err else "vl_out_endl();")
            return Val("0", NONE)

        vals = self.gen_args(e.args)

        if name == "len":
            v = vals[0]
            if is_str(v.ty):
                return Val(f"vl_str_len({v.expr})", INT)
            lc = self.list_cname(v.ty)
            return Val(f"{lc}_len({v.expr})", INT)

        if name == "utf8_len":
            return Val(f"vl_str_utf8_len({vals[0].expr})", INT)

        if name == "abs":
            v = vals[0]
            if is_float(v.ty):
                self.needs_math = True
                return Val(f"fabs((double)({v.expr}))", FLOAT)
            return Val(f"(({v.expr}) < 0 ? -({v.expr}) : ({v.expr}))", INT)

        if name in ("min", "max"):
            a, b = vals[0], vals[1]
            at = self.new_temp(a.ty, a.expr) if False else None
            cmp = "<" if name == "min" else ">"
            return Val(f"(({a.expr}) {cmp} ({b.expr}) ? ({a.expr}) : ({b.expr}))",
                       FLOAT if is_float(a.ty) or is_float(b.ty) else INT)

        if name in ("sqrt", "sin", "cos", "tan", "asin", "acos", "atan",
                    "log", "log2", "log10", "exp", "floor", "ceil", "round", "trunc"):
            self.needs_math = True
            fn = {"log2": "log2", "log10": "log10"}.get(name, name)
            return Val(f"{fn}((double)({vals[0].expr}))", FLOAT)

        if name in ("pow", "atan2"):
            self.needs_math = True
            return Val(f"{name}((double)({vals[0].expr}), (double)({vals[1].expr}))", FLOAT)

        if name in ("int", "to_int"):
            v = vals[0]
            if is_str(v.ty):
                return Val(f"vl_str_to_int({v.expr}, NULL)", INT)
            if is_bool(v.ty):
                return Val(f"((int64_t)({v.expr}))", INT)
            return Val(f"((int64_t)({v.expr}))", INT)

        if name in ("float", "to_float"):
            v = vals[0]
            if is_str(v.ty):
                return Val(f"vl_str_to_float({v.expr}, NULL)", FLOAT)
            return Val(f"((double)({v.expr}))", FLOAT)

        if name in ("str", "to_str"):
            v = vals[0]
            if is_str(v.ty):
                return Val(self.retain_expr(STR, v.expr), STR, owned=False)
            if is_bool(v.ty):
                nm = self.new_temp(STR, f"vl_str_from_bool({v.expr})")
                return Val(nm, STR, owned=True, temp=nm)
            if is_float(v.ty):
                nm = self.new_temp(STR, f"vl_str_from_f64((double)({v.expr}))")
                return Val(nm, STR, owned=True, temp=nm)
            nm = self.new_temp(STR, f"vl_str_from_i64((int64_t)({v.expr}))")
            return Val(nm, STR, owned=True, temp=nm)

        if name == "panic":
            self.emit(f"vl_panic_str({vals[0].expr});")
            return Val("0", NONE)

        if name == "assert":
            cond = vals[0].expr
            msg = e.args[0]
            fname = self.filename.replace("\\", "\\\\").replace('"', '\\"')
            expr_txt = getattr(msg, "_src_text", "") or "condition"
            self.emit(f'if (!({cond})) vl_assert_fail("{c_escape(expr_txt.encode("utf-8"))}", '
                      f'"{c_escape(fname.encode("utf-8"))}", {msg.line});')
            return Val("0", NONE)

        if name == "exit":
            self.emit(f"exit((int)({vals[0].expr}));")
            return Val("0", NONE)

        if name == "sort":
            v = vals[0]
            lc = self.list_cname(v.ty)
            self.emit(f"{lc}_sort({v.expr});")
            return Val("0", NONE)

        if name == "reverse":
            v = vals[0]
            lc = self.list_cname(v.ty)
            self.emit(f"{lc}_reverse({v.expr});")
            return Val("0", NONE)

        if name == "arg_count":
            return Val("vl_arg_count()", INT)

        if name == "arg":
            nm = self.new_temp(STR, f"vl_arg_get({vals[0].expr})")
            return Val(nm, STR, owned=True, temp=nm)

        if name == "read_file":
            nm = self.new_temp(STR, f"vl_read_file({vals[0].expr})")
            return Val(nm, STR, owned=True, temp=nm)

        if name == "write_file":
            return Val(f"vl_write_file({vals[0].expr}, {vals[1].expr})", INT)

        if name == "file_exists":
            return Val(f"vl_file_exists({vals[0].expr})", BOOL)

        if name == "fill":
            nm = self.new_temp(e.ty, f"{self.list_cname(e.ty)}_new()")
            self.emit(f"{self.list_cname(e.ty)}_fill({nm}, {vals[0].expr}, {vals[1].expr});")
            return Val(nm, e.ty, owned=True, temp=nm)

        raise RuntimeError(f"未实现的内建函数 {name}")

    def out_call(self, ty: Type, expr: str, to_err: bool) -> str:
        if to_err:
            if is_str(ty):
                return f"vl_err_str({expr});"
            if is_float(ty):
                return f"vl_err_f64((double)({expr}));"
            if is_bool(ty):
                return f"vl_err_cstr(({expr}) ? \"True\" : \"False\");"
            return f"vl_err_i64((int64_t)({expr}));"
        if is_str(ty):
            return f"vl_out_str({expr});"
        if is_float(ty):
            return f"vl_out_f64((double)({expr}));"
        if is_bool(ty):
            return f"vl_out_bool({expr});"
        return f"vl_out_i64((int64_t)({expr}));"

    def gen_method_call(self, e: A.Call, f: A.Attr) -> Val:
        obj = self.gen_expr(f.obj)
        oty = f.obj.ty
        m = f.name
        vals = self.gen_args(e.args)

        if isinstance(oty, ListT):
            lc = self.list_cname(oty)
            elem = oty.elem
            if m == "append" or m == "push":
                v = vals[0]
                if is_rc(elem):
                    if v.owned:
                        if v.temp:
                            self.mark_moved(v.temp)
                        self.emit(f"{lc}_push({obj.expr}, {v.expr});")
                    else:
                        self.emit(f"{lc}_push({obj.expr}, {self.retain_expr(elem, v.expr)});")
                else:
                    self.emit(f"{lc}_push({obj.expr}, {v.expr});")
                return Val("0", NONE)
            if m == "pop":
                if is_rc(elem):
                    nm = self.new_temp(elem, f"{lc}_pop({obj.expr})")
                    return Val(nm, elem, owned=True, temp=nm)
                return Val(f"{lc}_pop({obj.expr})", elem)
            if m == "insert":
                idx, v = vals[0], vals[1]
                if is_rc(elem):
                    if v.owned:
                        if v.temp:
                            self.mark_moved(v.temp)
                        self.emit(f"{lc}_insert({obj.expr}, {idx.expr}, {v.expr});")
                    else:
                        self.emit(f"{lc}_insert({obj.expr}, {idx.expr}, {self.retain_expr(elem, v.expr)});")
                else:
                    self.emit(f"{lc}_insert({obj.expr}, {idx.expr}, {v.expr});")
                return Val("0", NONE)
            if m == "remove":
                self.emit(f"{lc}_remove({obj.expr}, {vals[0].expr});")
                return Val("0", NONE)
            if m == "clear":
                self.emit(f"{lc}_clear({obj.expr});")
                return Val("0", NONE)
            if m == "sort":
                self.emit(f"{lc}_sort({obj.expr});")
                return Val("0", NONE)
            if m == "reverse":
                self.emit(f"{lc}_reverse({obj.expr});")
                return Val("0", NONE)
            if m == "index_of":
                return Val(f"{lc}_index_of({obj.expr}, {vals[0].expr})", INT)
            if m == "len":
                return Val(f"{lc}_len({obj.expr})", INT)

        if is_str(oty):
            s = obj.expr
            if m in ("upper", "lower", "trim", "trim_start", "trim_end"):
                fn = {"upper": "vl_str_upper", "lower": "vl_str_lower",
                      "trim": "vl_str_trim", "trim_start": "vl_str_trim_start",
                      "trim_end": "vl_str_trim_end"}[m]
                nm = self.new_temp(STR, f"{fn}({s})")
                return Val(nm, STR, owned=True, temp=nm)
            if m == "split":
                nm = self.new_temp(ListT(STR), f"vl_str_split({s}, {vals[0].expr})")
                return Val(nm, ListT(STR), owned=True, temp=nm)
            if m == "split_ws":
                nm = self.new_temp(ListT(STR), f"vl_str_split_ws({s})")
                return Val(nm, ListT(STR), owned=True, temp=nm)
            if m == "replace":
                nm = self.new_temp(STR, f"vl_str_replace({s}, {vals[0].expr}, {vals[1].expr})")
                return Val(nm, STR, owned=True, temp=nm)
            if m == "contains":
                return Val(f"vl_str_contains({s}, {vals[0].expr})", BOOL)
            if m == "starts_with":
                return Val(f"vl_str_starts_with({s}, {vals[0].expr})", BOOL)
            if m == "ends_with":
                return Val(f"vl_str_ends_with({s}, {vals[0].expr})", BOOL)
            if m == "find":
                return Val(f"vl_str_find({s}, {vals[0].expr}, 0)", INT)
            if m == "byte_at":
                return Val(f"vl_str_byte_at({s}, {vals[0].expr})", INT)
            if m == "char_at":
                nm = self.new_temp(STR, f"vl_str_char_at({s}, {vals[0].expr})")
                return Val(nm, STR, owned=True, temp=nm)
            if m == "repeat":
                nm = self.new_temp(STR, f"vl_str_repeat({s}, {vals[0].expr})")
                return Val(nm, STR, owned=True, temp=nm)
            if m == "to_int":
                return Val(f"vl_str_to_int({s}, NULL)", INT)
            if m == "to_float":
                return Val(f"vl_str_to_float({s}, NULL)", FLOAT)
            if m == "bytes":
                return Val(f"vl_str_len({s})", INT)
            if m == "join":
                nm = self.new_temp(STR, f"vl_str_join({vals[0].expr}, {s})")
                return Val(nm, STR, owned=True, temp=nm)

        raise RuntimeError(f"未实现的方法 {m}")


def generate(module: A.Module, ck: Checker, filename: str = "<velo>", source: str = "") -> str:
    g = CodeGen(module, ck, filename, source)
    g.gen_structs()
    return g.generate()
