"""构建环境：定位 MSVC 工具链，调用 cl.exe 把生成的 C 代码编译为原生 exe。

实现要点：Windows 上从 Python 直接以列表形式调用 `cmd /c` 会因引号转义
问题失败，因此这里统一用 `shell=True` 传入一条 "call vcvars64.bat && cl ..."
的命令串，既可靠又天然屏蔽了环境变量初始化过程。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional

CACHE_DIR = Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".velo"
ENV_CACHE = CACHE_DIR / "msvc_env.json"
VCVARS_CACHE = CACHE_DIR / "vcvars_path.txt"


class BuildError(Exception):
    pass


def _decode(b: bytes) -> str:
    for enc in ("utf-8", "mbcs", "gbk", "latin-1"):
        try:
            return b.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return b.decode("latin-1", errors="replace")


def _run_shell(cmdline: str, cwd: Optional[str] = None, timeout: int = 900,
               env: Optional[Dict[str, str]] = None) -> tuple:
    try:
        p = subprocess.run(cmdline, shell=True, capture_output=True,
                           cwd=cwd, timeout=timeout, env=env)
    except subprocess.TimeoutExpired:
        return 1, "编译超时"
    return p.returncode, _decode(p.stdout) + _decode(p.stderr)


def _run(args: List[str], timeout: int = 120) -> tuple:
    try:
        p = subprocess.run(args, capture_output=True, timeout=timeout)
    except (FileNotFoundError, OSError) as e:
        return 1, f"执行失败: {e}"
    return p.returncode, _decode(p.stdout) + _decode(p.stderr)


# ---------------------------------------------------------------- 定位 vcvars
def _cached_vcvars() -> Optional[Path]:
    try:
        if VCVARS_CACHE.exists():
            p = Path(VCVARS_CACHE.read_text(encoding="utf-8").strip())
            if p.exists():
                return p
    except Exception:
        pass
    return None


def _candidates() -> List[Path]:
    out: List[Path] = []
    env = os.environ.get("VELO_VCVARS")
    if env:
        out.append(Path(env))
    vswhere = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / \
        "Microsoft Visual Studio" / "Installer" / "vswhere.exe"
    if vswhere.exists():
        rc, txt = _run([str(vswhere), "-latest", "-products", "*",
                        "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                        "-property", "installationPath"])
        if rc == 0:
            for line in txt.splitlines():
                line = line.strip()
                if line:
                    out.append(Path(line) / "VC" / "Auxiliary" / "Build" / "vcvars64.bat")
    for base in (r"C:\Program Files\Microsoft Visual Studio",
                 r"C:\Program Files (x86)\Microsoft Visual Studio"):
        p = Path(base)
        if not p.exists():
            continue
        try:
            years = list(p.iterdir())
        except OSError:
            continue
        for year in years:
            if not year.is_dir():
                continue
            try:
                editions = list(year.iterdir())
            except OSError:
                continue
            for edition in editions:
                cand = edition / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"
                if cand.exists():
                    out.append(cand)
    return [c for c in out if c.exists()]


def find_vcvars(force: bool = False) -> Optional[Path]:
    if not force:
        cached = _cached_vcvars()
        if cached:
            return cached
    cands = _candidates()
    if not cands:
        return None
    best = cands[0]
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        VCVARS_CACHE.write_text(str(best), encoding="utf-8")
    except Exception:
        pass
    return best


def _parse_set_output(text: str) -> Dict[str, str]:
    env: Dict[str, str] = {}
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        if not k or k.startswith("="):
            continue
        env[k] = v.strip()
    return env


def msvc_env(force: bool = False) -> Dict[str, str]:
    """返回包含 MSVC 环境变量的 dict（用于诊断和 `veloc env`）。"""
    if not force and ENV_CACHE.exists():
        try:
            data = json.loads(ENV_CACHE.read_text(encoding="utf-8"))
            if data.get("env"):
                return data["env"]
        except Exception:
            pass

    vcvars = find_vcvars(force)
    if vcvars is None:
        raise BuildError(
            "未找到 MSVC 工具链。Velo 以 C 编译器作为后端，请安装 Visual Studio "
            "（勾选“使用 C++ 的桌面开发”工作负载），或设置环境变量 "
            "VELO_VCVARS 指向 vcvars64.bat。")

    rc, txt = _run_shell(f'call "{vcvars}" >nul 2>&1 && set')
    env = _parse_set_output(txt)
    if rc != 0 or "INCLUDE" not in env:
        raise BuildError(f"初始化 MSVC 环境失败（{vcvars}）。输出片段：\n{txt[:600]}")

    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        ENV_CACHE.write_text(json.dumps({"vcvars": str(vcvars), "env": env},
                                        ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return env


def runtime_dir() -> Path:
    """定位运行时库目录（velo_rt.h / velo_rt.c）。

    开发态在 <repo>/runtime；打包成单文件 exe 后位于 exe 同级的 runtime/。
    """
    here = Path(__file__).resolve().parent
    cand = (here.parent / "runtime").resolve()
    if cand.is_dir():
        return cand
    exe_dir = Path(sys.executable).resolve().parent
    cand2 = exe_dir / "runtime"
    if cand2.is_dir():
        return cand2
    return cand


def cl_location() -> str:
    """仅用于展示 cl.exe 的绝对路径。"""
    vcvars = find_vcvars()
    if vcvars:
        vsroot = vcvars.parent.parent.parent          # ...\<edition>\VC\Auxiliary\Build
        edition = vsroot.parent.parent                # ...\<edition>
        tools = edition / "VC" / "Tools" / "MSVC"
        if tools.exists():
            for ver in sorted(tools.iterdir(), reverse=True):
                cl = ver / "bin" / "Hostx64" / "x64" / "cl.exe"
                if cl.exists():
                    return str(cl)
    found = shutil.which("cl")
    return found or "cl（通过 vcvars 环境调用）"


# ---------------------------------------------------------------- 编译
def _tmp_root() -> Path:
    """找一个确实可写的临时目录。

    注意：内嵌 Python 环境下 tempfile.gettempdir() 不可靠，某些受限环境下
    %TEMP% 也可能没有写权限，因此这里逐个实测。
    """
    cands: List[Path] = []
    for key in ("TEMP", "TMP", "TMPDIR"):
        v = os.environ.get(key)
        if v:
            cands.append(Path(v))
    home = Path(os.environ.get("USERPROFILE") or str(Path.home()))
    cands.append(home / ".velo" / "tmp")
    try:
        cands.append(Path.cwd() / ".velo_tmp")
    except OSError:
        pass
    for p in cands:
        try:
            if not p.is_absolute():
                continue
            p.mkdir(parents=True, exist_ok=True)
            probe = p / f".vp_{os.getpid()}"
            with open(probe, "w", encoding="utf-8") as f:
                f.write("x")
            probe.unlink()
            return p
        except OSError:
            continue
    return Path(".")


def _make_workdir() -> Path:
    base = _tmp_root()
    for i in range(1000):
        cand = base / f"velo_{os.getpid()}_{int(time.time() * 1000) % 1000000}_{i}"
        try:
            cand.mkdir(parents=True, exist_ok=False)
            return cand
        except FileExistsError:
            continue
        except OSError:
            break
    d = base / f"velo_work_{os.getpid()}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def compile_c_to_exe(c_source: str, out_exe: Path, mode: str = "release",
                     extra_flags: Optional[List[str]] = None,
                     keep_dir: Optional[Path] = None,
                     include_dirs: Optional[List[str]] = None) -> Dict[str, object]:
    vcvars = find_vcvars()
    if vcvars is None:
        raise BuildError(
            "未找到 MSVC 工具链（vcvars64.bat）。Velo 需要 C 编译器作为后端，"
            "请安装 Visual Studio 的 C++ 桌面开发工作负载。")

    rt = runtime_dir()
    inc = [str(rt)] + [str(Path(d).resolve()) for d in (include_dirs or [])]

    if keep_dir:
        workdir = Path(keep_dir)
        workdir.mkdir(parents=True, exist_ok=True)
    else:
        workdir = _make_workdir()
    crate = workdir / "program.c"
    crate.write_text(c_source, encoding="utf-8", newline="\n")

    # cl/link 会往 TMP 里写响应文件，统一指向工作目录，避免权限问题
    env = dict(os.environ)
    env["TMP"] = str(workdir)
    env["TEMP"] = str(workdir)
    if "SystemRoot" not in env:
        env["SystemRoot"] = r"C:\Windows"

    exe = Path(out_exe).resolve()
    exe.parent.mkdir(parents=True, exist_ok=True)

    flags = ["/nologo", "/utf-8", "/W3", "/EHsc-",
             "/wd4244", "/wd4267", "/wd4100", "/wd4189", "/wd4996",
             "/wd4456", "/wd4457", "/wd4459", "/wd4505", "/wd4700"]
    if mode == "debug":
        flags += ["/Od", "/Zi", "/D_DEBUG"]
    elif mode == "fast":
        flags += ["/O2", "/Oi", "/Ot", "/Oy", "/GS-", "/DNDEBUG", "/arch:AVX2",
                  "/DVL_BOUNDS_CHECK=0"]
    else:
        flags += ["/O2", "/Oi", "/Ot", "/Oy", "/DNDEBUG"]
    for d in inc:
        flags.append(f"/I{d}")

    args = ["cl"] + flags + [f"/Fe:{exe}", "program.c"]
    cli = subprocess.list2cmdline(args)
    cmdline = f'call "{vcvars}" >nul 2>&1 && {cli}'

    rc, output = _run_shell(cmdline, cwd=str(workdir), env=env)
    ok = rc == 0 and exe.exists()

    result = {
        "ok": ok,
        "output": output,
        "workdir": str(workdir),
        "c_file": str(crate),
        "exe": str(exe),
        "cmdline": cmdline,
    }
    if ok and not keep_dir:
        shutil.rmtree(workdir, ignore_errors=True)
        result["workdir"] = ""
        result["c_file"] = ""
    return result


def looks_like_msvc_error(output: str) -> bool:
    return "error C" in output or "fatal error" in output
