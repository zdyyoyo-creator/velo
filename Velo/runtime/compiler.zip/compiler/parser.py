"""Velo 语法解析器 —— 递归下降 + 优先级爬升。"""
from __future__ import annotations

from typing import List, Optional

from . import ast_nodes as A
from .lexer import Token, VeloSyntaxError, tokenize

AUG_OPS = {"+=", "-=", "*=", "/=", "//=", "%=", "&=", "|=", "^=", "<<=", ">>=", "**="}


class Parser:
    def __init__(self, tokens: List[Token], filename: str = "<velo>"):
        self.toks = tokens
        self.i = 0
        self.filename = filename

    # ------------------------------------------------------------ 基础
    def cur(self) -> Token:
        return self.toks[self.i]

    def peek(self, off: int = 1) -> Token:
        j = self.i + off
        if j >= len(self.toks):
            return self.toks[-1]
        return self.toks[j]

    def at(self, kind: str, value=None) -> bool:
        t = self.cur()
        if t.kind != kind:
            return False
        return value is None or t.value == value

    def at_op(self, v: str) -> bool:
        return self.at("OP", v)

    def at_kw(self, v: str) -> bool:
        return self.at("KW", v)

    def error(self, msg: str, tok: Optional[Token] = None):
        t = tok or self.cur()
        raise VeloSyntaxError(msg, t.line, t.col, self.filename)

    def advance(self) -> Token:
        t = self.cur()
        if self.i < len(self.toks) - 1:
            self.i += 1
        return t

    def expect(self, kind: str, value=None) -> Token:
        if not self.at(kind, value):
            t = self.cur()
            want = value if value is not None else kind
            got = t.value if t.value != "" else t.kind
            self.error(f"期望 {want!r}，实际遇到 {got!r}", t)
        return self.advance()

    def skip_newlines(self):
        while self.at("NEWLINE"):
            self.advance()

    def end_stmt(self):
        if self.at("NEWLINE"):
            self.advance()
        elif self.at("EOF"):
            pass
        elif self.at("DEDENT"):
            pass
        else:
            self.error(f"语句结束后出现意外符号 {self.cur().value!r}")

    # ------------------------------------------------------------ 模块与语句
    def parse_module(self) -> A.Module:
        body: List[A.Node] = []
        self.skip_newlines()
        while not self.at("EOF"):
            body.append(self.parse_statement())
            self.skip_newlines()
        return A.Module(body=body)

    def parse_block(self) -> List[A.Node]:
        self.expect("OP", ":")
        self.expect("NEWLINE")
        self.expect("INDENT")
        body: List[A.Node] = []
        self.skip_newlines()
        while not self.at("DEDENT") and not self.at("EOF"):
            body.append(self.parse_statement())
            self.skip_newlines()
        if self.at("DEDENT"):
            self.advance()
        if not body:
            self.error("代码块不能为空（如需占位请写 pass）")
        return body

    def parse_statement(self) -> A.Node:
        t = self.cur()
        if t.kind == "KW":
            kw = t.value
            if kw == "def":
                return self.parse_func()
            if kw == "struct":
                return self.parse_struct()
            if kw == "enum":
                return self.parse_enum()
            if kw == "var":
                return self.parse_var(False)
            if kw == "const":
                return self.parse_var(True)
            if kw == "if" or kw == "elif":
                return self.parse_if()
            if kw == "while":
                return self.parse_while()
            if kw == "for":
                return self.parse_for()
            if kw == "return":
                line, col = t.line, t.col
                self.advance()
                value = None
                if not self.at("NEWLINE") and not self.at("EOF") and not self.at("DEDENT"):
                    value = self.parse_expr()
                self.end_stmt()
                return A.Return(line=line, col=col, value=value)
            if kw == "break":
                line, col = t.line, t.col
                self.advance()
                self.end_stmt()
                return A.Break(line=line, col=col)
            if kw == "continue":
                line, col = t.line, t.col
                self.advance()
                self.end_stmt()
                return A.Continue(line=line, col=col)
            if kw == "pass":
                line, col = t.line, t.col
                self.advance()
                self.end_stmt()
                return A.Pass(line=line, col=col)
            if kw == "extern":
                self.advance()
                if self.at_kw("def"):
                    return self.parse_func(is_extern=True)
                self.error("extern 后需要 def 声明")
            if kw == "import":
                return self.parse_import()
            if kw == "from":
                return self.parse_from_import()
            if kw == "else":
                self.error("else 缺少对应的 if")
            if kw in ("elif",):
                self.error("elif 缺少对应的 if")
            if kw == "defer":
                self.error("defer 将在后续版本提供，当前版本请手动释放资源")
            self.error(f"无法识别的语句起始关键字 {kw!r}")
        return self.parse_simple_statement()

    def parse_simple_statement(self) -> A.Node:
        line, col = self.cur().line, self.cur().col
        expr = self.parse_expr()
        t = self.cur()
        if t.kind == "OP" and t.value == "=":
            self.advance()
            value = self.parse_expr()
            self.end_stmt()
            return A.Assign(line=line, col=col, target=expr, value=value)
        if t.kind == "OP" and t.value in AUG_OPS:
            op = t.value[:-1]
            self.advance()
            value = self.parse_expr()
            self.end_stmt()
            return A.AugAssign(line=line, col=col, target=expr, op=op, value=value)
        self.end_stmt()
        return A.ExprStmt(line=line, col=col, value=expr)

    # ------------------------------------------------------------ 声明
    def parse_var(self, is_const: bool) -> A.VarDecl:
        t = self.expect("KW")
        line, col = t.line, t.col
        name = self.expect("IDENT").value
        type_ann = None
        if self.at_op(":"):
            self.advance()
            type_ann = self.parse_type()
        value = None
        if self.at_op("="):
            self.advance()
            value = self.parse_expr()
        self.end_stmt()
        if value is None and type_ann is None:
            self.error(f"变量 {name} 需要类型注解或初始值")
        return A.VarDecl(line=line, col=col, name=name, type_ann=type_ann,
                         value=value, is_const=is_const)

    def parse_type(self) -> A.TypeName:
        t = self.expect("IDENT")
        node = A.TypeName(name=t.value, line=t.line, col=t.col)
        if self.at_op("["):
            self.advance()
            while not self.at_op("]"):
                node.args.append(self.parse_type())
                if self.at_op(","):
                    self.advance()
                else:
                    break
            self.expect("OP", "]")
        return node

    def parse_func(self, is_extern: bool = False) -> A.FuncDef:
        line = self.cur().line
        col = self.cur().col
        self.expect("KW", "def")
        name = self.expect("IDENT").value
        self.expect("OP", "(")
        params: List[A.Param] = []
        while not self.at_op(")"):
            pt = self.expect("IDENT")
            ptype = None
            if self.at_op(":"):
                self.advance()
                ptype = self.parse_type()
            default = None
            if self.at_op("="):
                self.advance()
                default = self.parse_expr()
            params.append(A.Param(name=pt.value, type_ann=ptype, default=default,
                                  line=pt.line, col=pt.col))
            if self.at_op(","):
                self.advance()
            else:
                break
        self.expect("OP", ")")
        ret = None
        if self.at_op("->"):
            self.advance()
            ret = self.parse_type()
        if is_extern and not self.at_op(":"):
            self.end_stmt()
            return A.FuncDef(line=line, col=col, name=name, params=params,
                             ret_type=ret, body=[], is_extern=True)
        body = self.parse_block()
        return A.FuncDef(line=line, col=col, name=name, params=params,
                         ret_type=ret, body=body)

    def parse_struct(self) -> A.StructDef:
        t = self.expect("KW", "struct")
        line, col = t.line, t.col
        name = self.expect("IDENT").value
        self.expect("OP", ":")
        self.expect("NEWLINE")
        self.expect("INDENT")
        fields: List[A.StructField] = []
        self.skip_newlines()
        while not self.at("DEDENT") and not self.at("EOF"):
            ft = self.expect("IDENT")
            self.expect("OP", ":")
            ftype = self.parse_type()
            fields.append(A.StructField(name=ft.value, type_ann=ftype,
                                        line=ft.line, col=ft.col))
            self.end_stmt()
            self.skip_newlines()
        if self.at("DEDENT"):
            self.advance()
        if not fields:
            self.error("结构体至少需要一个字段")
        return A.StructDef(line=line, col=col, name=name, fields=fields)

    def parse_enum(self) -> A.EnumDef:
        t = self.expect("KW", "enum")
        line, col = t.line, t.col
        name = self.expect("IDENT").value
        self.expect("OP", ":")
        self.expect("NEWLINE")
        self.expect("INDENT")
        variants: List[str] = []
        self.skip_newlines()
        while not self.at("DEDENT") and not self.at("EOF"):
            variants.append(self.expect("IDENT").value)
            self.end_stmt()
            self.skip_newlines()
        if self.at("DEDENT"):
            self.advance()
        if not variants:
            self.error("枚举至少需要一个成员")
        return A.EnumDef(line=line, col=col, name=name, variants=variants)

    def parse_import(self) -> A.Import:
        t = self.expect("KW", "import")
        line, col = t.line, t.col
        module = self.parse_dotted()
        if self.at_kw("as"):
            self.advance()
            self.expect("IDENT")
        self.end_stmt()
        return A.Import(line=line, col=col, module=module, names=[])

    def parse_from_import(self) -> A.Import:
        t = self.expect("KW", "from")
        line, col = t.line, t.col
        module = self.parse_dotted()
        self.expect("KW", "import")
        names: List[str] = []
        while True:
            names.append(self.expect("IDENT").value)
            if self.at_kw("as"):
                self.advance()
                self.expect("IDENT")
            if self.at_op(","):
                self.advance()
            else:
                break
        self.end_stmt()
        return A.Import(line=line, col=col, module=module, names=names)

    def parse_dotted(self) -> str:
        parts = [self.expect("IDENT").value]
        while self.at_op("."):
            self.advance()
            parts.append(self.expect("IDENT").value)
        return ".".join(parts)

    # ------------------------------------------------------------ 控制流
    def parse_if(self) -> A.If:
        t = self.cur()
        line, col = t.line, t.col
        self.advance()  # if / elif
        cond = self.parse_expr()
        body = self.parse_block()
        orelse: List[A.Node] = []
        if self.at_kw("elif"):
            orelse = [self.parse_if()]
        elif self.at_kw("else"):
            self.advance()
            orelse = self.parse_block()
        return A.If(line=line, col=col, cond=cond, body=body, orelse=orelse)

    def parse_while(self) -> A.While:
        t = self.expect("KW", "while")
        cond = self.parse_expr()
        body = self.parse_block()
        return A.While(line=t.line, col=t.col, cond=cond, body=body)

    def parse_for(self) -> A.For:
        t = self.expect("KW", "for")
        target = self.expect("IDENT").value
        self.expect("KW", "in")
        it = self.parse_expr()
        body = self.parse_block()
        return A.For(line=t.line, col=t.col, target=target, iter=it, body=body)

    # ------------------------------------------------------------ 表达式
    def parse_expr(self) -> A.Node:
        return self.parse_ternary()

    def parse_ternary(self) -> A.Node:
        expr = self.parse_or()
        if self.at_kw("if"):
            self.advance()
            cond = self.parse_or()
            self.expect("KW", "else")
            other = self.parse_ternary()
            return A.CondExpr(cond=cond, then=expr, other=other)
        return expr

    def parse_or(self) -> A.Node:
        left = self.parse_and()
        while self.at_kw("or"):
            self.advance()
            right = self.parse_and()
            left = A.BinOp(op="or", left=left, right=right)
        return left

    def parse_and(self) -> A.Node:
        left = self.parse_not()
        while self.at_kw("and"):
            self.advance()
            right = self.parse_not()
            left = A.BinOp(op="and", left=left, right=right)
        return left

    def parse_not(self) -> A.Node:
        if self.at_kw("not"):
            t = self.advance()
            return A.UnaryOp(line=t.line, col=t.col, op="not", operand=self.parse_not())
        return self.parse_cmp()

    def parse_cmp(self) -> A.Node:
        left = self.parse_bitor()
        while True:
            t = self.cur()
            if t.kind == "OP" and t.value in ("==", "!=", "<", "<=", ">", ">="):
                self.advance()
                right = self.parse_bitor()
                left = A.BinOp(line=t.line, col=t.col, op=t.value, left=left, right=right)
            elif t.kind == "KW" and t.value == "in":
                self.advance()
                right = self.parse_bitor()
                left = A.BinOp(line=t.line, col=t.col, op="in", left=left, right=right)
            elif t.kind == "KW" and t.value == "is":
                self.advance()
                if self.at_kw("not"):
                    self.advance()
                    right = self.parse_bitor()
                    left = A.BinOp(line=t.line, col=t.col, op="is not", left=left, right=right)
                else:
                    right = self.parse_bitor()
                    left = A.BinOp(line=t.line, col=t.col, op="is", left=left, right=right)
            else:
                break
        return left

    def parse_bitor(self) -> A.Node:
        left = self.parse_bitxor()
        while self.at_op("|"):
            t = self.advance()
            left = A.BinOp(line=t.line, col=t.col, op="|", left=left, right=self.parse_bitxor())
        return left

    def parse_bitxor(self) -> A.Node:
        left = self.parse_bitand()
        while self.at_op("^"):
            t = self.advance()
            left = A.BinOp(line=t.line, col=t.col, op="^", left=left, right=self.parse_bitand())
        return left

    def parse_bitand(self) -> A.Node:
        left = self.parse_shift()
        while self.at_op("&"):
            t = self.advance()
            left = A.BinOp(line=t.line, col=t.col, op="&", left=left, right=self.parse_shift())
        return left

    def parse_shift(self) -> A.Node:
        left = self.parse_arith()
        while True:
            t = self.cur()
            if t.kind == "OP" and t.value in ("<<", ">>"):
                self.advance()
                left = A.BinOp(line=t.line, col=t.col, op=t.value, left=left, right=self.parse_arith())
            else:
                break
        return left

    def parse_arith(self) -> A.Node:
        left = self.parse_term()
        while True:
            t = self.cur()
            if t.kind == "OP" and t.value in ("+", "-"):
                self.advance()
                left = A.BinOp(line=t.line, col=t.col, op=t.value, left=left, right=self.parse_term())
            else:
                break
        return left

    def parse_term(self) -> A.Node:
        left = self.parse_unary()
        while True:
            t = self.cur()
            if t.kind == "OP" and t.value in ("*", "/", "//", "%"):
                self.advance()
                left = A.BinOp(line=t.line, col=t.col, op=t.value, left=left, right=self.parse_unary())
            else:
                break
        return left

    def parse_unary(self) -> A.Node:
        t = self.cur()
        if t.kind == "OP" and t.value in ("-", "+", "~"):
            self.advance()
            return A.UnaryOp(line=t.line, col=t.col, op=t.value, operand=self.parse_unary())
        return self.parse_power()

    def parse_power(self) -> A.Node:
        base = self.parse_postfix()
        if self.at_op("**"):
            t = self.advance()
            exp = self.parse_unary()
            return A.BinOp(line=t.line, col=t.col, op="**", left=base, right=exp)
        return base

    def parse_postfix(self) -> A.Node:
        expr = self.parse_atom()
        while True:
            if self.at_op("("):
                t = self.advance()
                args: List[A.Node] = []
                while not self.at_op(")"):
                    args.append(self.parse_expr())
                    if self.at_op(","):
                        self.advance()
                    else:
                        break
                self.expect("OP", ")")
                expr = A.Call(line=t.line, col=t.col, func=expr, args=args)
            elif self.at_op("["):
                t = self.advance()
                lower: Optional[A.Node] = None
                if not self.at_op(":"):
                    lower = self.parse_expr()
                if self.at_op(":"):
                    self.advance()
                    upper = None
                    if not self.at_op("]"):
                        upper = self.parse_expr()
                    self.expect("OP", "]")
                    expr = A.SliceExpr(line=t.line, col=t.col, obj=expr, lower=lower, upper=upper)
                else:
                    self.expect("OP", "]")
                    expr = A.Index(line=t.line, col=t.col, obj=expr, index=lower)
            elif self.at_op("."):
                self.advance()
                name_t = self.expect("IDENT")
                expr = A.Attr(line=name_t.line, col=name_t.col, obj=expr, name=name_t.value)
            else:
                break
        return expr

    def parse_atom(self) -> A.Node:
        t = self.cur()
        if t.kind == "INT":
            self.advance()
            return A.IntLit(line=t.line, col=t.col, value=t.value)
        if t.kind == "FLOAT":
            self.advance()
            return A.FloatLit(line=t.line, col=t.col, value=t.value)
        if t.kind == "STR":
            self.advance()
            parts = []
            for p in t.value:
                if p[0] == "lit":
                    parts.append(("lit", p[1]))
                else:
                    _, src, line, col = p
                    parts.append(("expr", self._parse_interp(src, line, col)))
            return A.StrLit(line=t.line, col=t.col, parts=parts)
        if t.kind == "IDENT":
            self.advance()
            return A.Name(line=t.line, col=t.col, id=t.value)
        if t.kind == "KW":
            if t.value == "True":
                self.advance()
                return A.BoolLit(line=t.line, col=t.col, value=True)
            if t.value == "False":
                self.advance()
                return A.BoolLit(line=t.line, col=t.col, value=False)
            if t.value == "None":
                self.advance()
                return A.NoneLit(line=t.line, col=t.col)
        if t.kind == "OP" and t.value == "(":
            self.advance()
            e = self.parse_expr()
            self.expect("OP", ")")
            return e
        if t.kind == "OP" and t.value == "[":
            self.advance()
            elems: List[A.Node] = []
            while not self.at_op("]"):
                elems.append(self.parse_expr())
                if self.at_op(","):
                    self.advance()
                else:
                    break
            self.expect("OP", "]")
            return A.ListLit(line=t.line, col=t.col, elems=elems)
        self.error(f"表达式中出现意外符号 {t.value!r}", t)

    def _parse_interp(self, src: str, line: int, col: int) -> A.Node:
        toks = tokenize(src, self.filename)
        sub = Parser(toks, self.filename)
        if sub.at("EOF"):
            raise VeloSyntaxError("插值表达式为空", line, col, self.filename)
        e = sub.parse_expr()
        sub.skip_newlines()
        if not sub.at("EOF"):
            raise VeloSyntaxError("插值表达式中存在多余内容", line, col, self.filename)
        return e


def parse(src: str, filename: str = "<velo>") -> A.Module:
    toks = tokenize(src, filename)
    return Parser(toks, filename).parse_module()
