"""Velo 语言编译器包。"""
from .checker import VeloTypeError, check
from .codegen import generate
from .lexer import VeloSyntaxError
from .parser import parse

__all__ = ["check", "generate", "parse", "VeloSyntaxError", "VeloTypeError", "__version__"]
__version__ = "1.0.0"
